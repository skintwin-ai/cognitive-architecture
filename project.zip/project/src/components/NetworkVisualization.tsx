import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { useSupplyChainStore } from '../store';
import { Node, Link } from '../types';
import { animateNodesAppear, animateLinksAppear, animateFlow, animateRiskEvent } from '../utils/animation';

interface NetworkVisualizationProps {
  width?: number;
  height?: number;
}

const NetworkVisualization: React.FC<NetworkVisualizationProps> = ({ 
  width = 900, 
  height = 600 
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const {
    network,
    selectedNodeId,
    selectedLinkId,
    activeRiskId,
    highlightedPath,
    hoveredElementId,
    isSimulating,
    simulationSpeed,
    selectNode,
    selectLink,
    setHoveredElement
  } = useSupplyChainStore();
  
  const [nodeElements, setNodeElements] = useState<SVGElement[]>([]);
  const [linkElements, setLinkElements] = useState<SVGElement[]>([]);
  const [flowAnimations, setFlowAnimations] = useState<{[key: string]: any}>({});
  const simulationRef = useRef<number | null>(null);
  
  // Type colors mapping
  const nodeColorMap = {
    'supplier': '#60a5fa', // blue-400
    'manufacturer': '#34d399', // emerald-400
    'distributor': '#a78bfa', // violet-400
    'retailer': '#f97316', // orange-500
    'customer': '#f43f5e', // rose-500
  };
  
  // Function to determine node radius based on capacity
  const getNodeSize = (node: Node) => {
    const baseSize = 8;
    const capacityFactor = node.capacity / 1000; // Normalize by max capacity
    return baseSize + capacityFactor * 12;
  };

  // Function to determine link stroke width based on quantity
  const getLinkWidth = (link: Link) => {
    const baseWidth = 1;
    const quantityFactor = link.quantity / 200; // Normalize by max quantity
    return baseWidth + quantityFactor * 3;
  };
  
  // Function to determine link color based on risk
  const getLinkColor = (link: Link) => {
    // Create a color scale from green (low risk) to red (high risk)
    if (!link.active) return '#6b7280'; // gray-500 for inactive links
    
    if (link.risk < 20) return '#22c55e'; // green-500
    if (link.risk < 40) return '#84cc16'; // lime-500
    if (link.risk < 60) return '#eab308'; // yellow-500
    if (link.risk < 80) return '#f97316'; // orange-500
    return '#ef4444'; // red-500
  };
  
  // Check if a node or link should be highlighted
  const isHighlighted = (id: string) => {
    if (selectedNodeId === id || selectedLinkId === id) return true;
    if (hoveredElementId === id) return true;
    if (highlightedPath.includes(id)) return true;
    if (activeRiskId) {
      const risk = network.risks.find(r => r.id === activeRiskId);
      if (risk && (risk.affectedNodeIds.includes(id) || risk.affectedLinkIds.includes(id))) {
        return true;
      }
    }
    return false;
  };
  
  // Function to get link opacity
  const getLinkOpacity = (link: Link) => {
    if (!selectedNodeId && !selectedLinkId && !hoveredElementId && highlightedPath.length === 0) {
      return link.active ? 0.7 : 0.3;
    }
    
    const isSelected = isHighlighted(link.id) || 
                         isHighlighted(link.source) || 
                         isHighlighted(link.target);
    
    return isSelected ? 1 : 0.1;
  };
  
  // Function to get node opacity
  const getNodeOpacity = (node: Node) => {
    if (!selectedNodeId && !selectedLinkId && !hoveredElementId && highlightedPath.length === 0) {
      return 1;
    }
    
    return isHighlighted(node.id) ? 1 : 0.3;
  };

  // Cleanup function for flow animations
  const cleanupFlowAnimations = () => {
    Object.values(flowAnimations).forEach(animation => {
      if (animation && animation.cleanup) {
        animation.cleanup();
      }
    });
    setFlowAnimations({});
  };

  // Function to run simulation
  const runSimulation = () => {
    if (!isSimulating) return;
    
    // Update animation speed based on settings
    const speedFactor = 1 - (network.settings.animationSpeed / 100); // Invert so higher = faster
    const baseDuration = 5000 * (speedFactor + 0.5); // Scale between 2500ms-7500ms
    
    // Animate flow on active links
    network.links.forEach(link => {
      if (link.active) {
        const linkElement = document.getElementById(`link-${link.id}`) as SVGElement;
        if (linkElement) {
          // Clear previous animation for this link if it exists
          if (flowAnimations[link.id] && flowAnimations[link.id].cleanup) {
            flowAnimations[link.id].cleanup();
          }
          
          // Create new animation
          const duration = baseDuration - (link.leadTime * 100);
          const animation = animateFlow(linkElement, duration, false);
          
          // Store the animation reference
          if (animation) {
            setFlowAnimations(prev => ({
              ...prev,
              [link.id]: animation
            }));
          }
        }
      }
    });
    
    // Schedule next cycle
    simulationRef.current = window.setTimeout(() => {
      runSimulation();
    }, baseDuration * 0.8); // Overlap slightly to keep continuous flow
  };

  // Effect to initialize visualization
  useEffect(() => {
    if (!svgRef.current) return;
    
    // Clear previous visualization
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();
    
    // Convert nodes and links for D3
    const nodes = network.nodes.map(node => ({ ...node }));
    
    const links = network.links.map(link => {
      // Find the source and target nodes
      const source = nodes.find(n => n.id === link.source);
      const target = nodes.find(n => n.id === link.target);
      
      return {
        ...link,
        source,
        target
      };
    });
    
    // Create SVG groups for links and nodes
    const g = svg.append('g');
    
    // Create simulation
    const simulation = d3.forceSimulation(nodes)
      .force('link', d3.forceLink(links)
        .id((d: any) => d.id)
        .distance(100))
      .force('charge', d3.forceManyBody().strength(-300))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide().radius(d => getNodeSize(d as Node) + 10));
    
    // Create links
    const linkGroup = g.append('g').attr('class', 'links');
    const linkElements = linkGroup.selectAll('path')
      .data(links)
      .enter()
      .append('path')
      .attr('id', d => `link-${d.id}`)
      .attr('stroke', d => getLinkColor(d as unknown as Link))
      .attr('stroke-width', d => getLinkWidth(d as unknown as Link))
      .attr('fill', 'none')
      .attr('opacity', d => getLinkOpacity(d as unknown as Link))
      .attr('stroke-dasharray', d => (d as unknown as Link).active ? '0' : '5,5')
      .on('click', (event, d) => {
        event.stopPropagation();
        selectLink((d as unknown as Link).id);
      })
      .on('mouseover', (event, d) => {
        setHoveredElement((d as unknown as Link).id);
      })
      .on('mouseout', () => {
        setHoveredElement(null);
      });
      
    // Create nodes
    const nodeGroup = g.append('g').attr('class', 'nodes');
    const nodeElements = nodeGroup.selectAll('circle')
      .data(nodes)
      .enter()
      .append('circle')
      .attr('id', d => `node-${d.id}`)
      .attr('r', d => getNodeSize(d as Node))
      .attr('fill', d => nodeColorMap[(d as Node).type])
      .attr('stroke', '#fff')
      .attr('stroke-width', 2)
      .attr('opacity', d => getNodeOpacity(d as Node))
      .attr('cursor', 'pointer')
      .on('click', (event, d) => {
        event.stopPropagation();
        selectNode((d as Node).id);
      })
      .on('mouseover', (event, d) => {
        setHoveredElement((d as Node).id);
      })
      .on('mouseout', () => {
        setHoveredElement(null);
      })
      .call(d3.drag<SVGCircleElement, any>()
        .on('start', (event, d) => {
          if (!event.active) simulation.alphaTarget(0.3).restart();
          d.fx = d.x;
          d.fy = d.y;
        })
        .on('drag', (event, d) => {
          d.fx = event.x;
          d.fy = event.y;
        })
        .on('end', (event, d) => {
          if (!event.active) simulation.alphaTarget(0);
          d.fx = null;
          d.fy = null;
        })
      );
    
    // Add node labels
    if (network.settings.showLabels) {
      const nodeLabels = nodeGroup.selectAll('text')
        .data(nodes)
        .enter()
        .append('text')
        .attr('text-anchor', 'middle')
        .attr('dy', d => -getNodeSize(d as Node) - 5)
        .attr('font-size', '10px')
        .attr('fill', '#374151') // gray-700
        .text(d => (d as Node).name)
        .attr('pointer-events', 'none');
        
      // Update label positions on simulation tick
      simulation.on('tick', () => {
        linkElements.attr('d', (d: any) => {
          const dx = d.target.x - d.source.x;
          const dy = d.target.y - d.source.y;
          const dr = Math.sqrt(dx * dx + dy * dy);
          
          // Don't curve the line for short distances
          if (dr < 200) {
            return `M${d.source.x},${d.source.y}L${d.target.x},${d.target.y}`;
          }
          
          // Curve the line for longer distances
          return `M${d.source.x},${d.source.y}A${dr},${dr} 0 0,1 ${d.target.x},${d.target.y}`;
        });
        
        nodeElements
          .attr('cx', d => Math.max(getNodeSize(d as Node), Math.min(width - getNodeSize(d as Node), d.x)))
          .attr('cy', d => Math.max(getNodeSize(d as Node), Math.min(height - getNodeSize(d as Node), d.y)));
          
        nodeLabels
          .attr('x', d => Math.max(getNodeSize(d as Node), Math.min(width - getNodeSize(d as Node), d.x)))
          .attr('y', d => Math.max(getNodeSize(d as Node), Math.min(height - getNodeSize(d as Node), d.y)));
      });
    } else {
      // Update positions on simulation tick when labels are disabled
      simulation.on('tick', () => {
        linkElements.attr('d', (d: any) => {
          const dx = d.target.x - d.source.x;
          const dy = d.target.y - d.source.y;
          const dr = Math.sqrt(dx * dx + dy * dy);
          
          if (dr < 200) {
            return `M${d.source.x},${d.source.y}L${d.target.x},${d.target.y}`;
          }
          
          return `M${d.source.x},${d.source.y}A${dr},${dr} 0 0,1 ${d.target.x},${d.target.y}`;
        });
        
        nodeElements
          .attr('cx', d => Math.max(getNodeSize(d as Node), Math.min(width - getNodeSize(d as Node), d.x)))
          .attr('cy', d => Math.max(getNodeSize(d as Node), Math.min(height - getNodeSize(d as Node), d.y)));
      });
    }
    
    // Apply animations
    const svgNodeElements = Array.from(document.querySelectorAll('.nodes circle')) as SVGElement[];
    const svgLinkElements = Array.from(document.querySelectorAll('.links path')) as SVGElement[];
    
    setNodeElements(svgNodeElements);
    setLinkElements(svgLinkElements);
    
    animateNodesAppear(svgNodeElements);
    animateLinksAppear(svgLinkElements);
    
    // Initial flow animations
    if (!isSimulating) {
      setTimeout(() => {
        network.links.forEach(link => {
          if (link.active) {
            const linkElement = document.getElementById(`link-${link.id}`) as SVGElement;
            if (linkElement) {
              animateFlow(linkElement, 4000 - link.leadTime * 200, true);
            }
          }
        });
      }, 1500);
    }
    
    // Add click handler to clear selection when clicking on the SVG background
    svg.on('click', () => {
      selectNode(null);
      selectLink(null);
    });
    
    return () => {
      simulation.stop();
    };
  }, [
    network.nodes, 
    network.links, 
    network.settings.showLabels,
    width, 
    height
  ]);
  
  // Apply animations when active risk changes
  useEffect(() => {
    if (activeRiskId) {
      const risk = network.risks.find(r => r.id === activeRiskId);
      if (!risk) return;
      
      // Find affected nodes and links
      const affectedNodes = nodeElements.filter(el => {
        const id = el.id.replace('node-', '');
        return risk.affectedNodeIds.includes(id);
      });
      
      const affectedLinks = linkElements.filter(el => {
        const id = el.id.replace('link-', '');
        return risk.affectedLinkIds.includes(id);
      });
      
      // Animate risk effects
      animateRiskEvent([...affectedNodes, ...affectedLinks], risk.severity);
    }
  }, [activeRiskId, network.risks, nodeElements, linkElements]);
  
  // Handle simulation state changes
  useEffect(() => {
    // Clean up any existing simulation
    if (simulationRef.current) {
      clearTimeout(simulationRef.current);
      simulationRef.current = null;
    }
    
    cleanupFlowAnimations();
    
    // Start simulation if enabled
    if (isSimulating) {
      runSimulation();
    }
    
    // Clean up on unmount
    return () => {
      if (simulationRef.current) {
        clearTimeout(simulationRef.current);
      }
      cleanupFlowAnimations();
    };
  }, [isSimulating, network.settings.animationSpeed]);
  
  return (
    <div className="relative w-full h-full overflow-hidden bg-white rounded-lg shadow-lg">
      <svg
        ref={svgRef}
        width={width}
        height={height}
        className="w-full h-full"
        style={{ minHeight: '500px' }}
      />
      
      {/* Legend */}
      <div className="absolute bottom-4 left-4 bg-white/80 backdrop-blur-sm p-3 rounded-lg shadow-sm text-xs">
        <div className="font-medium mb-1 text-gray-700">Node Types</div>
        <div className="flex flex-col gap-1">
          {Object.entries(nodeColorMap).map(([type, color]) => (
            <div key={type} className="flex items-center">
              <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: color }}></div>
              <span className="capitalize">{type}</span>
            </div>
          ))}
        </div>
      </div>
      
      {/* Simulation indicator */}
      {isSimulating && (
        <div className="absolute top-4 right-4 bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-medium animate-pulse">
          Simulation Running
        </div>
      )}
    </div>
  );
};

export default NetworkVisualization;