import React from 'react';
import { useSupplyChainStore } from '../store';
import { Network, TrendingUp, AlertOctagon, RefreshCw, Code, Database, Cpu } from 'lucide-react';

const Header: React.FC = () => {
  const { network, activeRiskId, resetToDefault, toggleAtomSpaceEditor, atomspaceEngine } = useSupplyChainStore();
  
  return (
    <header className="bg-white shadow-md rounded-lg py-4 px-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center">
          <Network className="h-8 w-8 text-blue-600 mr-3" />
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Supply Chain Network</h1>
            <p className="text-sm text-gray-500">Interactive visualization and simulation</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <button 
              onClick={resetToDefault}
              className="flex items-center px-3 py-2 bg-gray-50 rounded-lg border border-gray-200 text-gray-600 hover:text-blue-600 transition-colors duration-150"
              title="Reset to default"
            >
              <RefreshCw className="h-5 w-5 mr-1" />
              <span className="text-sm">Reset</span>
            </button>
            
            <button 
              onClick={toggleAtomSpaceEditor}
              className="flex items-center px-3 py-2 bg-indigo-50 rounded-lg border border-indigo-100 text-indigo-600 hover:bg-indigo-100 transition-colors duration-150"
              title="Open AtomSpace Editor"
            >
              <Code className="h-5 w-5 mr-1" />
              <span className="text-sm">AtomSpace</span>
              {atomspaceEngine && (
                <span className="ml-1 w-2 h-2 rounded-full bg-indigo-600"></span>
              )}
            </button>
          </div>
          
          <div className="flex gap-3 flex-wrap md:flex-nowrap">
            <DashboardMetric 
              icon={<TrendingUp className="h-5 w-5 text-emerald-500" />}
              label="Health Score"
              value={`${network.state.healthScore}%`}
              trend={activeRiskId ? 'down' : 'up'}
            />
            
            <DashboardMetric 
              icon={<AlertOctagon className="h-5 w-5 text-amber-500" />}
              label="Risk Score"
              value={`${network.state.riskScore}%`}
              trend={activeRiskId ? 'up' : 'down'}
              trendReversed
            />
            
            <DashboardMetric 
              icon={<Network className="h-5 w-5 text-blue-500" />}
              label="Resilience"
              value={`${network.state.resilience}%`}
              trend={network.settings.optimizeFor === 'resilience' ? 'up' : 'neutral'}
            />
            
            <DashboardMetric 
              icon={<Cpu className="h-5 w-5 text-indigo-500" />}
              label="Cognitive"
              value={atomspaceEngine ? "Active" : "Inactive"}
              trend={atomspaceEngine ? 'up' : 'neutral'}
            />
          </div>
        </div>
      </div>
      
      {activeRiskId && (
        <div className="mt-3 px-4 py-2 bg-red-50 border border-red-200 rounded-md flex items-center">
          <AlertOctagon className="h-5 w-5 text-red-600 mr-2" />
          <span className="text-sm text-red-700 font-medium">
            Active Risk Event: {network.risks.find(r => r.id === activeRiskId)?.name}
          </span>
        </div>
      )}
    </header>
  );
};

interface DashboardMetricProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  trend: 'up' | 'down' | 'neutral';
  trendReversed?: boolean;
}

const DashboardMetric: React.FC<DashboardMetricProps> = ({ 
  icon, 
  label, 
  value, 
  trend,
  trendReversed = false
}) => {
  // Determine trend arrow and color
  let trendIcon;
  let trendColor;
  
  if (trend === 'up') {
    trendIcon = '↑';
    trendColor = !trendReversed ? 'text-emerald-500' : 'text-red-500';
  } else if (trend === 'down') {
    trendIcon = '↓';
    trendColor = !trendReversed ? 'text-red-500' : 'text-emerald-500';
  } else {
    trendIcon = '→';
    trendColor = 'text-gray-400';
  }
  
  return (
    <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg border border-gray-200 min-w-[130px]">
      {icon}
      <div>
        <div className="text-xs text-gray-500">{label}</div>
        <div className="flex items-center">
          <span className="text-base font-semibold text-gray-800">{value}</span>
          <span className={`text-xs ml-1 ${trendColor}`}>{trendIcon}</span>
        </div>
      </div>
    </div>
  );
};

export default Header;