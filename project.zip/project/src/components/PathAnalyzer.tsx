import React, { useState, useEffect } from 'react';
import { useSupplyChainStore } from '../store';
import { BarChart4, Clock, AlertTriangle } from 'lucide-react';

const PathAnalyzer: React.FC = () => {
  const { 
    network, 
    selectedNodeId, 
    findOptimalPath, 
    highlightedPath,
    clearHighlightedPath
  } = useSupplyChainStore();
  
  const [sourceNodeId, setSourceNodeId] = useState<string>('');
  const [targetNodeId, setTargetNodeId] = useState<string>('');
  const [optimizationCriteria, setOptimizationCriteria] = useState<'cost' | 'time' | 'risk' | 'balanced'>('balanced');
  const [pathMetrics, setPathMetrics] = useState<{
    totalCost: number;
    totalTime: number;
    totalRisk: number;
    nodeCount: number;
  } | null>(null);
  
  // When selected node changes, use it as source or target
  useEffect(() => {
    if (selectedNodeId) {
      if (!sourceNodeId) {
        setSourceNodeId(selectedNodeId);
      } else if (sourceNodeId !== selectedNodeId && !targetNodeId) {
        setTargetNodeId(selectedNodeId);
      }
    }
  }, [selectedNodeId]);
  
  // When a path is highlighted, calculate its metrics
  useEffect(() => {
    if (highlightedPath.length > 0) {
      let totalCost = 0;
      let totalTime = 0;
      let totalRisk = 0;
      
      // For each consecutive pair of nodes in the path, find the corresponding link
      for (let i = 0; i < highlightedPath.length - 1; i++) {
        const source = highlightedPath[i];
        const target = highlightedPath[i + 1];
        
        const link = network.links.find(l => 
          l.source === source && l.target === target
        );
        
        if (link) {
          totalCost += link.cost;
          totalTime += link.leadTime;
          totalRisk += link.risk;
        }
      }
      
      setPathMetrics({
        totalCost,
        totalTime,
        totalRisk,
        nodeCount: highlightedPath.length
      });
    } else {
      setPathMetrics(null);
    }
  }, [highlightedPath, network.links]);
  
  const handleFindPath = () => {
    if (sourceNodeId && targetNodeId) {
      findOptimalPath(sourceNodeId, targetNodeId, optimizationCriteria);
    }
  };
  
  const handleClearPath = () => {
    clearHighlightedPath();
    setPathMetrics(null);
  };
  
  const getNodeNameById = (id: string) => {
    const node = network.nodes.find(node => node.id === id);
    return node ? node.name : id;
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-4 mt-4">
      <h3 className="font-medium text-lg mb-3">Supply Chain Path Analysis</h3>
      
      <div className="space-y-4">
        {/* Source and Target Selection */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Source Node
            </label>
            <select
              value={sourceNodeId}
              onChange={(e) => setSourceNodeId(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="">Select source...</option>
              {network.nodes
                .filter(node => node.type === 'supplier')
                .map(node => (
                  <option key={node.id} value={node.id}>{node.name}</option>
                ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Target Node
            </label>
            <select
              value={targetNodeId}
              onChange={(e) => setTargetNodeId(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="">Select target...</option>
              {network.nodes
                .filter(node => node.type === 'customer' || node.type === 'retailer')
                .map(node => (
                  <option key={node.id} value={node.id}>{node.name}</option>
                ))}
            </select>
          </div>
        </div>
        
        {/* Optimization Criteria */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Optimization Criteria
          </label>
          <div className="grid grid-cols-4 gap-2">
            <button
              onClick={() => setOptimizationCriteria('cost')}
              className={`px-3 py-2 text-xs font-medium rounded-md ${
                optimizationCriteria === 'cost'
                  ? 'bg-indigo-100 text-indigo-700 border-indigo-300'
                  : 'bg-white border-gray-200 text-gray-700'
              } border`}
            >
              <div className="flex flex-col items-center">
                <BarChart4 className="h-4 w-4 mb-1" />
                Cost
              </div>
            </button>
            
            <button
              onClick={() => setOptimizationCriteria('time')}
              className={`px-3 py-2 text-xs font-medium rounded-md ${
                optimizationCriteria === 'time'
                  ? 'bg-indigo-100 text-indigo-700 border-indigo-300'
                  : 'bg-white border-gray-200 text-gray-700'
              } border`}
            >
              <div className="flex flex-col items-center">
                <Clock className="h-4 w-4 mb-1" />
                Time
              </div>
            </button>
            
            <button
              onClick={() => setOptimizationCriteria('risk')}
              className={`px-3 py-2 text-xs font-medium rounded-md ${
                optimizationCriteria === 'risk'
                  ? 'bg-indigo-100 text-indigo-700 border-indigo-300'
                  : 'bg-white border-gray-200 text-gray-700'
              } border`}
            >
              <div className="flex flex-col items-center">
                <AlertTriangle className="h-4 w-4 mb-1" />
                Risk
              </div>
            </button>
            
            <button
              onClick={() => setOptimizationCriteria('balanced')}
              className={`px-3 py-2 text-xs font-medium rounded-md ${
                optimizationCriteria === 'balanced'
                  ? 'bg-indigo-100 text-indigo-700 border-indigo-300'
                  : 'bg-white border-gray-200 text-gray-700'
              } border`}
            >
              <div className="flex flex-col items-center">
                <BarChart4 className="h-4 w-4 mb-1" />
                Balanced
              </div>
            </button>
          </div>
        </div>
        
        {/* Action Buttons */}
        <div className="flex space-x-3">
          <button
            onClick={handleFindPath}
            disabled={!sourceNodeId || !targetNodeId}
            className={`flex-1 py-2 rounded-md text-sm font-medium ${
              !sourceNodeId || !targetNodeId
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white'
            }`}
          >
            Find Optimal Path
          </button>
          
          <button
            onClick={handleClearPath}
            disabled={highlightedPath.length === 0}
            className={`py-2 px-4 rounded-md text-sm font-medium ${
              highlightedPath.length === 0
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
            }`}
          >
            Clear
          </button>
        </div>
        
        {/* Path Results */}
        {pathMetrics && (
          <div className="mt-2 border border-gray-200 rounded-md p-3 bg-gray-50">
            <h4 className="font-medium text-sm mb-2">Path Analysis Results</h4>
            
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Total Cost:</span>
                <span className="font-medium">${pathMetrics.totalCost.toLocaleString()}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Lead Time:</span>
                <span className="font-medium">{pathMetrics.totalTime} days</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Risk Score:</span>
                <span className="font-medium">{(pathMetrics.totalRisk / (highlightedPath.length - 1)).toFixed(1)}%</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Nodes in Path:</span>
                <span className="font-medium">{pathMetrics.nodeCount}</span>
              </div>
              
              <div className="mt-2 pt-2 border-t border-gray-200">
                <div className="text-xs text-gray-600 mb-1">Path:</div>
                <div className="text-xs">
                  {highlightedPath.map((nodeId, index) => (
                    <span key={nodeId}>
                      {index > 0 && <span className="mx-1">→</span>}
                      <span className="font-medium">{getNodeNameById(nodeId)}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PathAnalyzer;