import React, { useState, useEffect, useMemo } from 'react';
import { useSupplyChainStore } from '../store';
import { AtomSpaceEngine, initializeSupplyChainRules } from '../utils/atomspaceEngine';
import { SupplyChainNode, SupplyChainLink, Rule, ReasoningResult } from '../types/atomspace';
import { 
  Save, 
  Code, 
  Search, 
  AlertTriangle, 
  Send, 
  X, 
  ZapIcon, 
  Database, 
  Network, 
  Brain,
  PlayCircle,
  Info,
  Filter,
  BarChart4
} from 'lucide-react';

const AtomSpaceEditor: React.FC = () => {
  const { network, updateNetwork } = useSupplyChainStore();
  const [atomspace, setAtomspace] = useState<AtomSpaceEngine | null>(null);
  const [selectedAtomId, setSelectedAtomId] = useState<string | null>(null);
  const [atomDetails, setAtomDetails] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [queryResults, setQueryResults] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'browse' | 'query' | 'reasoning' | 'analysis'>('browse');
  const [showEditor, setShowEditor] = useState(true);
  const [atomCode, setAtomCode] = useState('');
  const [atomFilter, setAtomFilter] = useState<'all' | 'nodes' | 'links'>('all');
  const [reasoningLogs, setReasoningLogs] = useState<ReasoningResult[]>([]);
  const [selectedRule, setSelectedRule] = useState<string | null>(null);
  const [isReasoning, setIsReasoning] = useState(false);
  const [filterType, setFilterType] = useState<string | null>(null);
  
  // Initialize AtomSpace when component mounts
  useEffect(() => {
    const engine = new AtomSpaceEngine('Supply Chain Network');
    engine.importSupplyChain(network.nodes, network.links);
    initializeSupplyChainRules(engine);
    setAtomspace(engine);
    
    // Listen for atom events
    engine.addEventListener((event) => {
      console.log('AtomSpace event:', event);
      
      // If an atom was updated and it's the selected one, update the details
      if (event.type === 'atom-updated' && event.data.atom.id === selectedAtomId) {
        setAtomDetails(event.data.atom);
      }
    });
  }, [network.nodes, network.links]);
  
  // Update atom details when selection changes
  useEffect(() => {
    if (atomspace && selectedAtomId) {
      const atom = atomspace.getAtom(selectedAtomId);
      setAtomDetails(atom);
      
      // Convert atom to JSON string for editor
      if (atom) {
        setAtomCode(JSON.stringify(atom, null, 2));
      }
    } else {
      setAtomDetails(null);
      setAtomCode('');
    }
  }, [atomspace, selectedAtomId]);
  
  // Handle search/query
  useEffect(() => {
    if (!atomspace || !searchQuery) {
      setQueryResults([]);
      return;
    }
    
    // Perform basic search
    const allAtoms = atomspace.getAllAtoms();
    const results = allAtoms.filter(atom => 
      atom.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      atom.id.includes(searchQuery) ||
      JSON.stringify(atom).toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    setQueryResults(results);
  }, [atomspace, searchQuery]);
  
  // Get rules when atomspace changes
  const rules = useMemo(() => {
    if (!atomspace) return [];
    return atomspace.getAllRules();
  }, [atomspace]);
  
  // Get filtered atoms based on current filter
  const getFilteredAtoms = () => {
    if (!atomspace) return [];
    
    let atoms = [];
    
    switch (atomFilter) {
      case 'nodes':
        atoms = atomspace.getAllNodes();
        break;
      case 'links':
        atoms = atomspace.getAllLinks();
        break;
      case 'all':
      default:
        atoms = atomspace.getAllAtoms();
        break;
    }
    
    // Apply type filter if set
    if (filterType) {
      atoms = atoms.filter(atom => atom.type === filterType);
    }
    
    return atoms;
  };
  
  // Apply atom changes from editor
  const applyAtomChanges = () => {
    if (!atomspace || !selectedAtomId) return;
    
    try {
      const updatedAtom = JSON.parse(atomCode);
      const result = atomspace.updateAtom(selectedAtomId, updatedAtom);
      
      if (result) {
        // If successful, update the network
        const { nodes, links } = atomspace.exportSupplyChain();
        updateNetwork(nodes, links);
        setAtomDetails(result);
      }
    } catch (error) {
      console.error('Error updating atom:', error);
      alert('Invalid JSON format. Please check your edits.');
    }
  };
  
  // Apply a rule
  const applyRule = async (ruleId: string) => {
    if (!atomspace) return;
    
    setIsReasoning(true);
    
    try {
      // Apply the rule
      const result = atomspace.applyRule(ruleId);
      
      if (result) {
        setReasoningLogs(prev => [...prev, result]);
        
        // Update the network
        const { nodes, links } = atomspace.exportSupplyChain();
        updateNetwork(nodes, links);
      }
    } catch (error) {
      console.error('Error applying rule:', error);
    } finally {
      setIsReasoning(false);
    }
  };
  
  // Run forward chaining
  const runForwardChaining = async () => {
    if (!atomspace) return;
    
    setIsReasoning(true);
    
    try {
      const results = atomspace.runForwardChaining(5);
      setReasoningLogs(results);
      
      // Update the network
      const { nodes, links } = atomspace.exportSupplyChain();
      updateNetwork(nodes, links);
    } catch (error) {
      console.error('Error running forward chaining:', error);
    } finally {
      setIsReasoning(false);
    }
  };
  
  // Analyze network resilience
  const analyzeNetworkResilience = () => {
    if (!atomspace) return;
    
    const resilienceAnalysis = atomspace.analyzeResilience();
    
    // Show the analysis as a new atom
    const analysisAtom = {
      id: `resilience-analysis-${Date.now()}`,
      type: 'ConceptNode',
      name: 'Network Resilience Analysis',
      value: resilienceAnalysis,
      strength: resilienceAnalysis.resilienceScore / 100,
      confidence: 0.9
    };
    
    atomspace.addAtom(analysisAtom);
    setSelectedAtomId(analysisAtom.id);
  };
  
  // Calculate network centrality
  const calculateNetworkCentrality = () => {
    if (!atomspace) return;
    
    const centralityMeasures = atomspace.calculateCentrality();
    
    // Create a centrality analysis atom
    const analysisAtom = {
      id: `centrality-analysis-${Date.now()}`,
      type: 'ConceptNode',
      name: 'Network Centrality Analysis',
      value: centralityMeasures,
      strength: 1.0,
      confidence: 0.95
    };
    
    atomspace.addAtom(analysisAtom);
    setSelectedAtomId(analysisAtom.id);
  };
  
  // Get node type color
  const getNodeTypeColor = (nodeType: string) => {
    const colorMap: Record<string, string> = {
      'supplier': 'bg-blue-100 text-blue-800',
      'manufacturer': 'bg-emerald-100 text-emerald-800',
      'distributor': 'bg-violet-100 text-violet-800',
      'retailer': 'bg-orange-100 text-orange-800',
      'customer': 'bg-rose-100 text-rose-800',
    };
    
    return colorMap[nodeType] || 'bg-gray-100 text-gray-800';
  };
  
  // Get atom type badge color
  const getAtomTypeColor = (atomType: string) => {
    const colorMap: Record<string, string> = {
      'ConceptNode': 'bg-blue-100 text-blue-800',
      'PredicateNode': 'bg-purple-100 text-purple-800',
      'VariableNode': 'bg-gray-100 text-gray-800',
      'EvaluationLink': 'bg-emerald-100 text-emerald-800',
      'InheritanceLink': 'bg-amber-100 text-amber-800',
      'MemberLink': 'bg-indigo-100 text-indigo-800',
    };
    
    return colorMap[atomType] || 'bg-gray-100 text-gray-800';
  };
  
  // Helper to format atom display
  const formatAtomDisplay = (atom: any) => {
    if (!atom) return '';
    
    if (atom.type === 'ConceptNode') {
      return atom.name || atom.id.substring(0, 8);
    } else if (atom.type.includes('Link')) {
      return `${atom.type} (${atom.id.substring(0, 6)})`;
    }
    
    return atom.id.substring(0, 8);
  };
  
  // Get unique atom types for filtering
  const atomTypes = useMemo(() => {
    if (!atomspace) return [];
    
    const types = new Set<string>();
    atomspace.getAllAtoms().forEach(atom => {
      types.add(atom.type);
    });
    
    return Array.from(types);
  }, [atomspace]);
  
  return (
    <div className={`fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 transition-opacity ${showEditor ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      <div className="bg-white w-full max-w-6xl h-5/6 rounded-lg shadow-xl flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center">
            <Brain className="h-6 w-6 text-indigo-500 mr-2" />
            <h2 className="text-xl font-semibold text-gray-800">AtomSpace Knowledge Graph</h2>
          </div>
          <button 
            onClick={() => setShowEditor(false)}
            className="p-1 rounded-full hover:bg-gray-100"
          >
            <X className="h-6 w-6 text-gray-500" />
          </button>
        </div>
        
        {/* Tabs */}
        <div className="px-6 py-2 border-b border-gray-200">
          <div className="flex space-x-4">
            <button
              onClick={() => setActiveTab('browse')}
              className={`px-3 py-2 text-sm font-medium rounded-md flex items-center ${
                activeTab === 'browse' 
                  ? 'bg-indigo-100 text-indigo-700' 
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Database className="h-4 w-4 mr-1.5" />
              Browse Atoms
            </button>
            <button
              onClick={() => setActiveTab('query')}
              className={`px-3 py-2 text-sm font-medium rounded-md flex items-center ${
                activeTab === 'query' 
                  ? 'bg-indigo-100 text-indigo-700' 
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Search className="h-4 w-4 mr-1.5" />
              Query
            </button>
            <button
              onClick={() => setActiveTab('reasoning')}
              className={`px-3 py-2 text-sm font-medium rounded-md flex items-center ${
                activeTab === 'reasoning' 
                  ? 'bg-indigo-100 text-indigo-700' 
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Brain className="h-4 w-4 mr-1.5" />
              Reasoning
            </button>
            <button
              onClick={() => setActiveTab('analysis')}
              className={`px-3 py-2 text-sm font-medium rounded-md flex items-center ${
                activeTab === 'analysis' 
                  ? 'bg-indigo-100 text-indigo-700' 
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <BarChart4 className="h-4 w-4 mr-1.5" />
              Analysis
            </button>
          </div>
        </div>
        
        {/* Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left panel - Browse or search atoms */}
          <div className="w-1/2 border-r border-gray-200 flex flex-col">
            {activeTab === 'browse' && (
              <>
                <div className="p-4 border-b border-gray-200">
                  <div className="flex items-center mb-2 space-x-2">
                    <button
                      onClick={() => setAtomFilter('all')}
                      className={`px-2 py-1 text-xs font-medium rounded ${
                        atomFilter === 'all' ? 'bg-gray-200' : 'bg-gray-100'
                      }`}
                    >
                      All
                    </button>
                    <button
                      onClick={() => setAtomFilter('nodes')}
                      className={`px-2 py-1 text-xs font-medium rounded ${
                        atomFilter === 'nodes' ? 'bg-gray-200' : 'bg-gray-100'
                      }`}
                    >
                      Nodes
                    </button>
                    <button
                      onClick={() => setAtomFilter('links')}
                      className={`px-2 py-1 text-xs font-medium rounded ${
                        atomFilter === 'links' ? 'bg-gray-200' : 'bg-gray-100'
                      }`}
                    >
                      Links
                    </button>
                    
                    <div className="ml-auto">
                      <select 
                        value={filterType || ''} 
                        onChange={(e) => setFilterType(e.target.value || null)}
                        className="text-xs border border-gray-200 rounded px-2 py-1"
                      >
                        <option value="">All Types</option>
                        {atomTypes.map(type => (
                          <option key={type} value={type}>{type}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  
                  <div className="text-xs text-gray-500">
                    {atomspace ? `${getFilteredAtoms().length} atoms found` : 'Loading atoms...'}
                  </div>
                </div>
                
                <div className="flex-1 overflow-y-auto">
                  {getFilteredAtoms().map((atom) => (
                    <div
                      key={atom.id}
                      className={`p-3 border-b border-gray-100 hover:bg-gray-50 cursor-pointer ${
                        selectedAtomId === atom.id ? 'bg-indigo-50' : ''
                      }`}
                      onClick={() => setSelectedAtomId(atom.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <span className={`inline-block px-2 py-1 text-xs font-medium rounded ${getAtomTypeColor(atom.type)}`}>
                            {atom.type}
                          </span>
                          
                          {atom.type === 'ConceptNode' && (atom as any).nodeType && (
                            <span className={`ml-2 inline-block px-2 py-1 text-xs font-medium rounded ${getNodeTypeColor((atom as any).nodeType)}`}>
                              {(atom as any).nodeType}
                            </span>
                          )}
                        </div>
                        
                        <span className="text-xs text-gray-500">
                          {atom.id.substring(0, 8)}...
                        </span>
                      </div>
                      
                      <div className="mt-1 text-sm font-medium text-gray-800">
                        {atom.name || formatAtomDisplay(atom)}
                      </div>
                      
                      <div className="mt-1 flex items-center text-xs text-gray-500">
                        <div className="flex items-center mr-4">
                          <span>Strength:</span>
                          <div className="ml-1 w-16 h-2 bg-gray-200 rounded">
                            <div 
                              className="h-full bg-green-500 rounded" 
                              style={{ width: `${atom.strength * 100}%` }}
                            ></div>
                          </div>
                        </div>
                        
                        <div className="flex items-center">
                          <span>Confidence:</span>
                          <div className="ml-1 w-16 h-2 bg-gray-200 rounded">
                            <div 
                              className="h-full bg-blue-500 rounded" 
                              style={{ width: `${atom.confidence * 100}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
            
            {activeTab === 'query' && (
              <>
                <div className="p-4 border-b border-gray-200">
                  <div className="flex">
                    <input
                      type="text"
                      placeholder="Search atoms..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    />
                    <button className="px-4 py-2 bg-indigo-600 text-white rounded-r-md flex items-center">
                      <Search className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                
                <div className="flex-1 overflow-y-auto">
                  {queryResults.length > 0 ? (
                    queryResults.map((atom) => (
                      <div
                        key={atom.id}
                        className={`p-3 border-b border-gray-100 hover:bg-gray-50 cursor-pointer ${
                          selectedAtomId === atom.id ? 'bg-indigo-50' : ''
                        }`}
                        onClick={() => setSelectedAtomId(atom.id)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <span className={`inline-block px-2 py-1 text-xs font-medium rounded ${getAtomTypeColor(atom.type)}`}>
                              {atom.type}
                            </span>
                            
                            {atom.type === 'ConceptNode' && (atom as any).nodeType && (
                              <span className={`ml-2 inline-block px-2 py-1 text-xs font-medium rounded ${getNodeTypeColor((atom as any).nodeType)}`}>
                                {(atom as any).nodeType}
                              </span>
                            )}
                          </div>
                          
                          <span className="text-xs text-gray-500">
                            {atom.id.substring(0, 8)}...
                          </span>
                        </div>
                        
                        <div className="mt-1 text-sm font-medium text-gray-800">
                          {atom.name || formatAtomDisplay(atom)}
                        </div>
                        
                        <div className="mt-1 text-xs text-gray-500">
                          Strength: {(atom.strength * 100).toFixed(0)}% • Confidence: {(atom.confidence * 100).toFixed(0)}%
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-4 text-center text-gray-500">
                      {searchQuery ? 'No results found' : 'Enter a search term to find atoms'}
                    </div>
                  )}
                </div>
              </>
            )}
            
            {activeTab === 'reasoning' && (
              <div className="flex-1 flex flex-col overflow-hidden">
                <div className="p-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-800 mb-2 flex items-center">
                    <Brain className="h-5 w-5 mr-1.5 text-indigo-500" />
                    Reasoning Engine
                  </h3>
                  
                  <div className="flex space-x-2 mb-4">
                    <button
                      onClick={runForwardChaining}
                      disabled={isReasoning}
                      className={`px-3 py-1.5 text-sm rounded-md flex items-center ${
                        isReasoning
                          ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                          : 'bg-indigo-600 text-white hover:bg-indigo-700'
                      }`}
                    >
                      <PlayCircle className="h-4 w-4 mr-1.5" />
                      Run Forward Chaining
                    </button>
                  </div>
                </div>
                
                <div className="p-4 flex-1 overflow-y-auto">
                  <h4 className="font-medium text-gray-700 mb-2">Available Rules</h4>
                  
                  <div className="space-y-2 mb-6">
                    {rules.map(rule => (
                      <div 
                        key={rule.id}
                        className={`p-2 rounded border ${
                          selectedRule === rule.id 
                            ? 'border-indigo-300 bg-indigo-50' 
                            : 'border-gray-200 bg-white'
                        } hover:border-indigo-300 cursor-pointer`}
                        onClick={() => setSelectedRule(rule.id)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <ZapIcon className="h-4 w-4 text-indigo-500 mr-1.5" />
                            <span className="font-medium text-gray-800">{rule.name}</span>
                          </div>
                          
                          <button 
                            className="px-2 py-1 text-xs bg-indigo-100 text-indigo-700 rounded hover:bg-indigo-200"
                            onClick={(e) => {
                              e.stopPropagation();
                              applyRule(rule.id);
                            }}
                            disabled={isReasoning}
                          >
                            Apply
                          </button>
                        </div>
                        
                        <p className="text-xs text-gray-600 mt-1 ml-5.5">
                          {rule.description}
                        </p>
                        
                        <div className="mt-1 ml-5.5 text-xs text-gray-500">
                          Computational cost: {rule.cost * 100}%
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <h4 className="font-medium text-gray-700 mb-2">Reasoning Log</h4>
                  
                  {reasoningLogs.length > 0 ? (
                    <div className="space-y-2">
                      {reasoningLogs.map((result, index) => (
                        <div key={index} className="p-2 bg-gray-50 rounded border border-gray-200">
                          <div className="flex items-center text-sm font-medium text-gray-800">
                            <Info className="h-4 w-4 mr-1.5 text-blue-500" />
                            Rule applied: {atomspace?.getRule(result.steps[0].ruleId)?.name || 'Unknown rule'}
                          </div>
                          
                          <div className="mt-1 text-xs">
                            <div className="text-gray-600">
                              Derived {result.derivedAtoms.length} new atoms with confidence {(result.confidence * 100).toFixed(1)}%
                            </div>
                            
                            {result.derivedAtoms.length > 0 && (
                              <div className="mt-2 p-2 bg-gray-100 rounded max-h-32 overflow-y-auto">
                                {result.derivedAtoms.map((atom, i) => (
                                  <div 
                                    key={i} 
                                    className="hover:bg-indigo-50 cursor-pointer p-1 rounded text-xs flex items-center"
                                    onClick={() => setSelectedAtomId(atom.id)}
                                  >
                                    <span className={`inline-block w-2 h-2 rounded-full mr-1.5 ${
                                      atom.type.includes('Link') ? 'bg-emerald-400' : 'bg-blue-400'
                                    }`}></span>
                                    {formatAtomDisplay(atom)}
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-sm text-gray-500 italic">
                      No reasoning results available. Apply a rule or run forward chaining to generate results.
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {activeTab === 'analysis' && (
              <div className="p-4 flex-1 overflow-y-auto">
                <h3 className="text-lg font-medium text-gray-800 mb-4 flex items-center">
                  <BarChart4 className="h-5 w-5 mr-1.5 text-indigo-500" />
                  Supply Chain Analysis
                </h3>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <button
                    onClick={analyzeNetworkResilience}
                    className="p-4 bg-white rounded-lg border border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-colors duration-150 flex flex-col items-center"
                  >
                    <Network className="h-6 w-6 text-indigo-500 mb-2" />
                    <span className="font-medium text-gray-800">Resilience Analysis</span>
                    <p className="text-xs text-gray-500 text-center mt-1">
                      Evaluate network resilience and identify vulnerabilities
                    </p>
                  </button>
                  
                  <button
                    onClick={calculateNetworkCentrality}
                    className="p-4 bg-white rounded-lg border border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-colors duration-150 flex flex-col items-center"
                  >
                    <Database className="h-6 w-6 text-blue-500 mb-2" />
                    <span className="font-medium text-gray-800">Centrality Metrics</span>
                    <p className="text-xs text-gray-500 text-center mt-1">
                      Calculate node importance and centrality measures
                    </p>
                  </button>
                </div>
                
                {/* Risk Evaluation */}
                <div className="mb-6">
                  <h4 className="font-medium text-gray-700 mb-2 flex items-center">
                    <AlertTriangle className="h-4 w-4 mr-1.5 text-amber-500" />
                    Risk Evaluation
                  </h4>
                  
                  <button
                    onClick={() => {
                      if (!atomspace) return;
                      const riskAnalysis = atomspace.evaluateRisks();
                      
                      // Create a risk analysis atom
                      const analysisAtom = {
                        id: `risk-analysis-${Date.now()}`,
                        type: 'ConceptNode',
                        name: 'Risk Analysis Result',
                        value: riskAnalysis,
                        strength: 1.0 - (riskAnalysis.overallRisk / 100),
                        confidence: 0.9
                      };
                      
                      atomspace.addAtom(analysisAtom);
                      setSelectedAtomId(analysisAtom.id);
                    }}
                    className="w-full p-3 bg-white rounded-lg border border-amber-200 hover:bg-amber-50 transition-colors duration-150"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-gray-800">Calculate Network Risk</span>
                      <ZapIcon className="h-4 w-4 text-amber-500" />
                    </div>
                    <p className="text-xs text-left text-gray-500 mt-1">
                      Identify critical nodes, links, and overall risk score
                    </p>
                  </button>
                </div>
                
                {/* Advanced Analysis */}
                <div>
                  <h4 className="font-medium text-gray-700 mb-2">Advanced Analysis</h4>
                  
                  <div className="space-y-2">
                    <button
                      onClick={() => {
                        // For this example, we'll just create a placeholder analysis result
                        if (!atomspace) return;
                        
                        const analysisAtom = {
                          id: `optimization-analysis-${Date.now()}`,
                          type: 'ConceptNode',
                          name: 'Supply Chain Optimization Recommendations',
                          value: {
                            recommendations: [
                              "Increase supplier diversity for critical materials",
                              "Reduce lead times on high-risk connections",
                              "Add redundancy for bottleneck nodes",
                              "Implement risk monitoring for high centrality nodes"
                            ],
                            metrics: {
                              potentialCostSavings: "$12,500",
                              resilienceImprovement: "15%",
                              riskReduction: "22%"
                            }
                          },
                          strength: 0.85,
                          confidence: 0.75
                        };
                        
                        atomspace.addAtom(analysisAtom);
                        setSelectedAtomId(analysisAtom.id);
                      }}
                      className="w-full p-2 bg-white rounded-lg border border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-colors duration-150 flex items-center justify-between"
                    >
                      <div className="text-left">
                        <span className="font-medium text-gray-800">Optimization Recommendations</span>
                        <p className="text-xs text-gray-500 mt-0.5">
                          Generate cost, time, and resilience improvement recommendations
                        </p>
                      </div>
                      <ZapIcon className="h-4 w-4 text-indigo-500" />
                    </button>
                    
                    <button
                      onClick={() => {
                        if (!atomspace) return;
                        
                        // Get network statistics
                        const nodes = atomspace.getAllNodes();
                        const links = atomspace.getAllLinks();
                        
                        // Node type counts
                        const nodeTypeCounts: Record<string, number> = {};
                        for (const node of nodes) {
                          const nodeType = (node as any).nodeType || 'unknown';
                          nodeTypeCounts[nodeType] = (nodeTypeCounts[nodeType] || 0) + 1;
                        }
                        
                        // Link statistics
                        const linkStats = {
                          avgLeadTime: links.reduce((sum, link) => sum + ((link as any).leadTime || 0), 0) / links.length,
                          avgCost: links.reduce((sum, link) => sum + ((link as any).cost || 0), 0) / links.length,
                          avgRisk: links.reduce((sum, link) => sum + ((link as any).risk || 0), 0) / links.length,
                          totalQuantity: links.reduce((sum, link) => sum + ((link as any).quantity || 0), 0)
                        };
                        
                        // Create stats atom
                        const statsAtom = {
                          id: `network-stats-${Date.now()}`,
                          type: 'ConceptNode',
                          name: 'Network Statistics',
                          value: {
                            nodeCount: nodes.length,
                            linkCount: links.length,
                            nodeTypeCounts,
                            linkStats
                          },
                          strength: 1.0,
                          confidence: 1.0
                        };
                        
                        atomspace.addAtom(statsAtom);
                        setSelectedAtomId(statsAtom.id);
                      }}
                      className="w-full p-2 bg-white rounded-lg border border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-colors duration-150 flex items-center justify-between"
                    >
                      <div className="text-left">
                        <span className="font-medium text-gray-800">Network Statistics</span>
                        <p className="text-xs text-gray-500 mt-0.5">
                          Calculate comprehensive network metrics
                        </p>
                      </div>
                      <BarChart4 className="h-4 w-4 text-indigo-500" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Right panel - Atom details and editor */}
          <div className="w-1/2 flex flex-col">
            {selectedAtomId && atomDetails ? (
              <>
                <div className="p-4 border-b border-gray-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <span className={`inline-block px-2 py-1 text-xs font-medium rounded ${getAtomTypeColor(atomDetails.type)}`}>
                        {atomDetails.type}
                      </span>
                      
                      {atomDetails.type === 'ConceptNode' && atomDetails.nodeType && (
                        <span className={`ml-2 inline-block px-2 py-1 text-xs font-medium rounded ${getNodeTypeColor(atomDetails.nodeType)}`}>
                          {atomDetails.nodeType}
                        </span>
                      )}
                      
                      <span className="ml-2 text-sm text-gray-500">
                        ID: {atomDetails.id.substring(0, 8)}...
                      </span>
                    </div>
                    
                    <div>
                      <button 
                        className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-md text-sm font-medium flex items-center"
                        onClick={applyAtomChanges}
                      >
                        <Save className="h-4 w-4 mr-1" />
                        Save Changes
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4">
                  {atomDetails.value && (
                    <div className="mb-4">
                      <h3 className="text-sm font-medium text-gray-700 mb-1">Value Data</h3>
                      <div className="bg-gray-50 p-3 rounded-lg border border-gray-200 text-xs font-mono overflow-auto">
                        <pre className="whitespace-pre-wrap">
                          {JSON.stringify(atomDetails.value, null, 2)}
                        </pre>
                      </div>
                    </div>
                  )}
                  
                  <div className="mb-4">
                    <h3 className="text-sm font-medium text-gray-700 mb-1">Atom JSON</h3>
                    <textarea
                      value={atomCode}
                      onChange={(e) => setAtomCode(e.target.value)}
                      className="w-full h-64 p-4 border border-gray-300 rounded-md font-mono text-sm"
                    />
                  </div>
                  
                  <div className="mt-4">
                    <h3 className="text-sm font-medium text-gray-700 mb-2">Truth Value</h3>
                    
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">Strength</label>
                        <div className="flex items-center">
                          <div className="flex-1 h-2 bg-gray-200 rounded mr-2">
                            <div 
                              className="h-full bg-green-500 rounded" 
                              style={{ width: `${atomDetails.strength * 100}%` }}
                            ></div>
                          </div>
                          <span className="text-xs font-medium">{(atomDetails.strength * 100).toFixed(1)}%</span>
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">Confidence</label>
                        <div className="flex items-center">
                          <div className="flex-1 h-2 bg-gray-200 rounded mr-2">
                            <div 
                              className="h-full bg-blue-500 rounded" 
                              style={{ width: `${atomDetails.confidence * 100}%` }}
                            ></div>
                          </div>
                          <span className="text-xs font-medium">{(atomDetails.confidence * 100).toFixed(1)}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Connected Atoms Section */}
                  <div className="mt-4">
                    <h3 className="text-sm font-medium text-gray-700 mb-2">Related Atoms</h3>
                    
                    {atomDetails.type.includes('Link') && (
                      <div className="space-y-2">
                        <h4 className="text-xs font-medium text-gray-600">Outgoing Set:</h4>
                        {(atomDetails as any).outgoingSet?.map((nodeId: string) => {
                          const node = atomspace?.getAtom(nodeId);
                          return (
                            <div 
                              key={nodeId}
                              className="p-2 bg-gray-50 rounded border border-gray-200 flex items-center justify-between cursor-pointer hover:bg-gray-100"
                              onClick={() => setSelectedAtomId(nodeId)}
                            >
                              <div>
                                <span className={`inline-block px-2 py-1 text-xs font-medium rounded ${getAtomTypeColor(node?.type || '')}`}>
                                  {node?.type}
                                </span>
                                <span className="ml-2 text-sm font-medium">
                                  {node?.name || nodeId.substring(0, 8)}
                                </span>
                              </div>
                              <span className="text-xs text-blue-600">View →</span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                    
                    {!atomDetails.type.includes('Link') && (
                      <div>
                        <div className="mb-2">
                          <h4 className="text-xs font-medium text-gray-600">Incoming Links:</h4>
                          <div className="space-y-2 mt-1">
                            {atomspace?.getIncomingLinks(atomDetails.id)
                              .map(link => (
                                <div 
                                  key={link.id}
                                  className="p-2 bg-gray-50 rounded border border-gray-200 flex items-center justify-between cursor-pointer hover:bg-gray-100"
                                  onClick={() => setSelectedAtomId(link.id)}
                                >
                                  <div>
                                    <span className={`inline-block px-2 py-1 text-xs font-medium rounded ${getAtomTypeColor(link.type)}`}>
                                      {link.type}
                                    </span>
                                    <span className="ml-2 text-sm font-medium">
                                      {formatAtomDisplay(link)}
                                    </span>
                                  </div>
                                  <span className="text-xs text-blue-600">View →</span>
                                </div>
                              ))}
                              
                            {atomspace?.getIncomingLinks(atomDetails.id).length === 0 && (
                              <div className="text-xs text-gray-500 italic p-2">No incoming links</div>
                            )}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="text-xs font-medium text-gray-600">Outgoing Links:</h4>
                          <div className="space-y-2 mt-1">
                            {atomspace?.getOutgoingLinks(atomDetails.id)
                              .map(link => (
                                <div 
                                  key={link.id}
                                  className="p-2 bg-gray-50 rounded border border-gray-200 flex items-center justify-between cursor-pointer hover:bg-gray-100"
                                  onClick={() => setSelectedAtomId(link.id)}
                                >
                                  <div>
                                    <span className={`inline-block px-2 py-1 text-xs font-medium rounded ${getAtomTypeColor(link.type)}`}>
                                      {link.type}
                                    </span>
                                    <span className="ml-2 text-sm font-medium">
                                      {formatAtomDisplay(link)}
                                    </span>
                                  </div>
                                  <span className="text-xs text-blue-600">View →</span>
                                </div>
                              ))}
                              
                            {atomspace?.getOutgoingLinks(atomDetails.id).length === 0 && (
                              <div className="text-xs text-gray-500 italic p-2">No outgoing links</div>
                            )}
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {/* Connected Nodes */}
                    {!atomDetails.type.includes('Link') && (
                      <div className="mt-3">
                        <h4 className="text-xs font-medium text-gray-600">Connected Nodes:</h4>
                        <div className="space-y-2 mt-1">
                          {atomspace?.getConnectedNodes(atomDetails.id)
                            .map(node => (
                              <div 
                                key={node.id}
                                className="p-2 bg-gray-50 rounded border border-gray-200 flex items-center justify-between cursor-pointer hover:bg-gray-100"
                                onClick={() => setSelectedAtomId(node.id)}
                              >
                                <div className="flex items-center">
                                  <span className={`inline-block px-2 py-1 text-xs font-medium rounded ${getAtomTypeColor(node.type)}`}>
                                    {node.type}
                                  </span>
                                  
                                  {(node as any).nodeType && (
                                    <span className={`ml-2 inline-block px-2 py-1 text-xs font-medium rounded ${getNodeTypeColor((node as any).nodeType)}`}>
                                      {(node as any).nodeType}
                                    </span>
                                  )}
                                </div>
                                
                                <span className="ml-2 text-sm font-medium">
                                  {node.name || node.id.substring(0, 8)}
                                </span>
                                <span className="text-xs text-blue-600">View →</span>
                              </div>
                            ))}
                            
                          {atomspace?.getConnectedNodes(atomDetails.id).length === 0 && (
                            <div className="text-xs text-gray-500 italic p-2">No connected nodes</div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <div className="mb-4 inline-block p-4 bg-indigo-50 rounded-full">
                    <Brain className="h-8 w-8 text-indigo-500" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-800 mb-1">No Atom Selected</h3>
                  <p className="text-gray-500">
                    Select an atom from the list to view and edit its details
                  </p>
                  
                  <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100 text-sm text-blue-800 max-w-sm mx-auto">
                    <h4 className="font-medium mb-2 flex items-center">
                      <Info className="h-4 w-4 mr-1" />
                      AtomSpace Tips
                    </h4>
                    <ul className="text-xs space-y-1 list-disc pl-4">
                      <li>Browse and edit atoms in the knowledge graph</li>
                      <li>Apply inference rules to derive new knowledge</li>
                      <li>Run analysis tools to gain supply chain insights</li>
                      <li>Make changes here to update the visualization</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Footer */}
        <div className="px-6 py-3 border-t border-gray-200 flex justify-between items-center">
          <div className="text-xs text-gray-500">
            {atomspace ? `AtomSpace contains ${atomspace.getAllAtoms().length} atoms (${atomspace.getAllNodes().length} nodes, ${atomspace.getAllLinks().length} links)` : 'Loading AtomSpace...'}
          </div>
          
          <div>
            <button 
              onClick={() => {
                if (atomspace) {
                  const { nodes, links } = atomspace.exportSupplyChain();
                  updateNetwork(nodes, links);
                  setShowEditor(false);
                }
              }}
              className="px-4 py-2 bg-indigo-600 text-white rounded-md text-sm font-medium flex items-center"
            >
              <Send className="h-4 w-4 mr-2" />
              Apply Changes to Network
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AtomSpaceEditor;