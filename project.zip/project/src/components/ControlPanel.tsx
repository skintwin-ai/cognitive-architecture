import React, { useState, useEffect } from 'react';
import { useSupplyChainStore } from '../store';
import { Settings, Zap, AlertTriangle, BarChart4, Hexagon, RefreshCw, Route } from 'lucide-react';
import PathAnalyzer from './PathAnalyzer';

const ControlPanel: React.FC = () => {
  const { 
    network, 
    isSimulating, 
    toggleSimulation,
    updateSettings,
    optimizeNetwork,
    triggerRiskEvent,
    resolveRiskEvent,
    activeRiskId,
    updateSimulation,
    toggleAtomSpaceEditor
  } = useSupplyChainStore();
  
  const [activeTab, setActiveTab] = useState<'settings' | 'risks' | 'optimize' | 'analysis'>('settings');
  
  // Run simulation update interval
  useEffect(() => {
    if (!isSimulating) return;
    
    // Calculate tick interval based on animation speed
    const speedFactor = network.settings.animationSpeed / 100;
    const interval = 1000 - (speedFactor * 800); // Between 200ms and 1000ms
    
    const simulationInterval = setInterval(() => {
      updateSimulation();
    }, interval);
    
    return () => clearInterval(simulationInterval);
  }, [isSimulating, network.settings.animationSpeed, updateSimulation]);
  
  // Render the settings panel
  const renderSettingsPanel = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Risk Probability
        </label>
        <input 
          type="range" 
          min="0" 
          max="100" 
          value={network.settings.riskProbability} 
          onChange={e => updateSettings({ riskProbability: Number(e.target.value) })}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>Low</span>
          <span>{network.settings.riskProbability}%</span>
          <span>High</span>
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Demand Volatility
        </label>
        <input 
          type="range" 
          min="0" 
          max="100" 
          value={network.settings.demandVolatility} 
          onChange={e => updateSettings({ demandVolatility: Number(e.target.value) })}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>Stable</span>
          <span>{network.settings.demandVolatility}%</span>
          <span>Volatile</span>
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Animation Speed
        </label>
        <input 
          type="range" 
          min="0" 
          max="100" 
          value={network.settings.animationSpeed} 
          onChange={e => updateSettings({ animationSpeed: Number(e.target.value) })}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>Slow</span>
          <span>{network.settings.animationSpeed}%</span>
          <span>Fast</span>
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Visualization Mode
        </label>
        <select 
          value={network.settings.visualizationMode}
          onChange={e => updateSettings({ visualizationMode: e.target.value as any })}
          className="w-full px-3 py-2 text-sm bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="force-directed">Force-Directed</option>
          <option value="geographic">Geographic</option>
          <option value="sankey">Sankey</option>
        </select>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Display Options
        </label>
        <div className="flex items-center mb-2">
          <input 
            type="checkbox" 
            id="show-labels" 
            checked={network.settings.showLabels}
            onChange={e => updateSettings({ showLabels: e.target.checked })}
            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
          />
          <label htmlFor="show-labels" className="ml-2 text-sm text-gray-700">
            Show Labels
          </label>
        </div>
        <div className="flex items-center">
          <input 
            type="checkbox" 
            id="high-contrast" 
            checked={network.settings.highContrastMode}
            onChange={e => updateSettings({ highContrastMode: e.target.checked })}
            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
          />
          <label htmlFor="high-contrast" className="ml-2 text-sm text-gray-700">
            High Contrast Mode
          </label>
        </div>
      </div>
      
      <div className="pt-4 mt-4 border-t border-gray-200">
        <button
          onClick={toggleAtomSpaceEditor}
          className="w-full py-2 px-4 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-md border border-indigo-200 flex items-center justify-center"
        >
          <Hexagon className="h-4 w-4 mr-1" />
          Open AtomSpace Editor
        </button>
      </div>
    </div>
  );
  
  // Render the risks panel
  const renderRisksPanel = () => (
    <div className="space-y-4">
      <p className="text-sm text-gray-600 mb-2">
        Trigger a risk event to see how it affects the supply chain network.
      </p>
      
      {network.risks.map(risk => (
        <div 
          key={risk.id} 
          className={`p-3 rounded-lg border ${
            activeRiskId === risk.id ? 'bg-red-50 border-red-200' : 'bg-white border-gray-200'
          } hover:bg-gray-50 cursor-pointer transition-colors duration-150`}
          onClick={() => triggerRiskEvent(risk.id)}
        >
          <div className="flex items-center justify-between">
            <div className="font-medium text-gray-900">{risk.name}</div>
            <div className={`px-2 py-1 rounded-full text-xs ${
              risk.severity > 70 ? 'bg-red-100 text-red-800' :
              risk.severity > 50 ? 'bg-orange-100 text-orange-800' :
              risk.severity > 30 ? 'bg-yellow-100 text-yellow-800' :
              'bg-green-100 text-green-800'
            }`}>
              Severity: {risk.severity}%
            </div>
          </div>
          <p className="text-sm text-gray-600 mt-1">{risk.description}</p>
          <div className="flex items-center text-xs text-gray-500 mt-2">
            <div className="flex items-center">
              <span className="mr-1">Probability:</span>
              <span className="font-medium">{risk.probability}%</span>
            </div>
            <div className="mx-2">•</div>
            <div className="flex items-center">
              <span className="mr-1">Affected Nodes:</span>
              <span className="font-medium">{risk.affectedNodeIds.length}</span>
            </div>
            <div className="mx-2">•</div>
            <div className="flex items-center">
              <span className="mr-1">Affected Links:</span>
              <span className="font-medium">{risk.affectedLinkIds.length}</span>
            </div>
          </div>
        </div>
      ))}
      
      {activeRiskId && (
        <button
          onClick={resolveRiskEvent}
          className="w-full py-2 px-4 mt-4 bg-blue-600 hover:bg-blue-700 text-white rounded-md shadow transition-colors duration-150"
        >
          Resolve Active Risk Event
        </button>
      )}
    </div>
  );
  
  // Render the optimization panel
  const renderOptimizePanel = () => (
    <div className="space-y-4">
      <p className="text-sm text-gray-600 mb-2">
        Optimize your supply chain network based on different strategies.
      </p>
      
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => optimizeNetwork('cost')}
          className={`p-4 rounded-lg border ${
            network.settings.optimizeFor === 'cost' ? 'bg-blue-50 border-blue-200' : 'bg-white border-gray-200'
          } hover:bg-gray-50 flex flex-col items-center justify-center transition-colors duration-150`}
        >
          <BarChart4 className="h-6 w-6 text-blue-500 mb-2" />
          <div className="font-medium text-gray-800">Cost</div>
          <p className="text-xs text-gray-500 text-center mt-1">
            Minimize total supply chain costs
          </p>
        </button>
        
        <button
          onClick={() => optimizeNetwork('resilience')}
          className={`p-4 rounded-lg border ${
            network.settings.optimizeFor === 'resilience' ? 'bg-blue-50 border-blue-200' : 'bg-white border-gray-200'
          } hover:bg-gray-50 flex flex-col items-center justify-center transition-colors duration-150`}
        >
          <Hexagon className="h-6 w-6 text-indigo-500 mb-2" />
          <div className="font-medium text-gray-800">Resilience</div>
          <p className="text-xs text-gray-500 text-center mt-1">
            Maximize risk resistance
          </p>
        </button>
        
        <button
          onClick={() => optimizeNetwork('speed')}
          className={`p-4 rounded-lg border ${
            network.settings.optimizeFor === 'speed' ? 'bg-blue-50 border-blue-200' : 'bg-white border-gray-200'
          } hover:bg-gray-50 flex flex-col items-center justify-center transition-colors duration-150`}
        >
          <Zap className="h-6 w-6 text-amber-500 mb-2" />
          <div className="font-medium text-gray-800">Speed</div>
          <p className="text-xs text-gray-500 text-center mt-1">
            Minimize lead times
          </p>
        </button>
        
        <button
          onClick={() => optimizeNetwork('balanced')}
          className={`p-4 rounded-lg border ${
            network.settings.optimizeFor === 'balanced' ? 'bg-blue-50 border-blue-200' : 'bg-white border-gray-200'
          } hover:bg-gray-50 flex flex-col items-center justify-center transition-colors duration-150`}
        >
          <RefreshCw className="h-6 w-6 text-emerald-500 mb-2" />
          <div className="font-medium text-gray-800">Balanced</div>
          <p className="text-xs text-gray-500 text-center mt-1">
            Find optimal trade-offs
          </p>
        </button>
      </div>
      
      <div className="mt-6 p-3 bg-gray-50 rounded-lg border border-gray-200">
        <h4 className="font-medium text-gray-800 mb-2">Optimization Results</h4>
        <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Cost:</span>
            <span className="font-medium">${network.state.totalCost.toLocaleString()}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Resilience:</span>
            <span className="font-medium">{network.state.resilience}%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Efficiency:</span>
            <span className="font-medium">{network.state.efficiency}%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Risk Score:</span>
            <span className="font-medium">{network.state.riskScore}%</span>
          </div>
        </div>
      </div>
    </div>
  );
  
  // Render the analysis panel
  const renderAnalysisPanel = () => (
    <div className="space-y-4">
      <PathAnalyzer />
    </div>
  );
  
  return (
    <div className="bg-white p-4 rounded-lg shadow-lg w-full">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Control Panel</h3>
        <div className="flex">
          <button
            onClick={toggleSimulation}
            className={`ml-2 px-3 py-1 rounded-md text-sm font-medium ${
              isSimulating 
                ? 'bg-red-100 text-red-700 hover:bg-red-200' 
                : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
            } transition-colors duration-150`}
          >
            {isSimulating ? 'Stop Simulation' : 'Start Simulation'}
          </button>
        </div>
      </div>
      
      <div className="border-b border-gray-200 mb-4">
        <nav className="flex -mb-px">
          <button
            onClick={() => setActiveTab('settings')}
            className={`mr-4 py-2 px-1 text-sm font-medium ${
              activeTab === 'settings'
                ? 'border-b-2 border-blue-500 text-blue-600'
                : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } transition-colors duration-150 flex items-center`}
          >
            <Settings className="h-4 w-4 mr-1" />
            Settings
          </button>
          <button
            onClick={() => setActiveTab('risks')}
            className={`mr-4 py-2 px-1 text-sm font-medium ${
              activeTab === 'risks'
                ? 'border-b-2 border-blue-500 text-blue-600'
                : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } transition-colors duration-150 flex items-center`}
          >
            <AlertTriangle className="h-4 w-4 mr-1" />
            Risks
          </button>
          <button
            onClick={() => setActiveTab('optimize')}
            className={`mr-4 py-2 px-1 text-sm font-medium ${
              activeTab === 'optimize'
                ? 'border-b-2 border-blue-500 text-blue-600'
                : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } transition-colors duration-150 flex items-center`}
          >
            <Zap className="h-4 w-4 mr-1" />
            Optimize
          </button>
          <button
            onClick={() => setActiveTab('analysis')}
            className={`py-2 px-1 text-sm font-medium ${
              activeTab === 'analysis'
                ? 'border-b-2 border-blue-500 text-blue-600'
                : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } transition-colors duration-150 flex items-center`}
          >
            <Route className="h-4 w-4 mr-1" />
            Analysis
          </button>
        </nav>
      </div>
      
      <div className="pb-2">
        {activeTab === 'settings' && renderSettingsPanel()}
        {activeTab === 'risks' && renderRisksPanel()}
        {activeTab === 'optimize' && renderOptimizePanel()}
        {activeTab === 'analysis' && renderAnalysisPanel()}
      </div>
      
      {/* Simulation status */}
      {isSimulating && (
        <div className="mt-4 pt-4 border-t border-gray-200">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-gray-700">Simulation Active</span>
            <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
              Updates dynamically
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default ControlPanel;