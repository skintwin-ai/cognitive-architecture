import { create } from 'zustand';
import { SupplyChainNetwork, Node, Link, RiskEvent, SimulationSettings } from '../types';
import demoNetwork from '../utils/demoData';
import { AtomSpaceEngine, createSupplyChainAtomSpace, initializeSupplyChainRules } from '../utils/atomspaceEngine';

interface SupplyChainState {
  network: SupplyChainNetwork;
  selectedNodeId: string | null;
  selectedLinkId: string | null;
  activeRiskId: string | null;
  isSimulating: boolean;
  simulationSpeed: number;
  highlightedPath: string[];
  hoveredElementId: string | null;
  simulationTime: number;
  atomspaceEngine: AtomSpaceEngine | null;
  showAtomSpaceEditor: boolean;
  
  // Actions
  selectNode: (nodeId: string | null) => void;
  selectLink: (linkId: string | null) => void;
  setActiveRisk: (riskId: string | null) => void;
  updateNode: (nodeId: string, updates: Partial<Node>) => void;
  updateLink: (linkId: string, updates: Partial<Link>) => void;
  addNode: (node: Node) => void;
  addLink: (link: Link) => void;
  removeNode: (nodeId: string) => void;
  removeLink: (linkId: string) => void;
  updateSettings: (settings: Partial<SimulationSettings>) => void;
  toggleSimulation: () => void;
  setSimulationSpeed: (speed: number) => void;
  setHighlightedPath: (nodeIds: string[]) => void;
  clearHighlightedPath: () => void;
  setHoveredElement: (id: string | null) => void;
  resetToDefault: () => void;
  optimizeNetwork: (strategy: 'cost' | 'resilience' | 'speed' | 'balanced') => void;
  triggerRiskEvent: (riskId: string) => void;
  resolveRiskEvent: () => void;
  updateSimulation: () => void;
  toggleAtomSpaceEditor: () => void;
  updateNetwork: (nodes: any[], links: any[]) => void;
  findOptimalPath: (sourceId: string, targetId: string, criteria: 'cost' | 'time' | 'risk' | 'balanced') => void;
}

export const useSupplyChainStore = create<SupplyChainState>((set, get) => ({
  network: { ...demoNetwork },
  selectedNodeId: null,
  selectedLinkId: null,
  activeRiskId: null,
  isSimulating: false,
  simulationSpeed: 50,
  highlightedPath: [],
  hoveredElementId: null,
  simulationTime: 0,
  atomspaceEngine: null,
  showAtomSpaceEditor: false,

  selectNode: (nodeId) => set({ selectedNodeId: nodeId, selectedLinkId: null }),
  
  selectLink: (linkId) => set({ selectedLinkId: linkId, selectedNodeId: null }),
  
  setActiveRisk: (riskId) => set({ activeRiskId: riskId }),
  
  updateNode: (nodeId, updates) => set((state) => {
    const newNetwork = {
      ...state.network,
      nodes: state.network.nodes.map((node) => 
        node.id === nodeId ? { ...node, ...updates } : node
      )
    };
    
    // Update the atomspace if it exists
    if (state.atomspaceEngine) {
      state.atomspaceEngine.importSupplyChain(newNetwork.nodes, newNetwork.links);
    }
    
    return { network: newNetwork };
  }),
  
  updateLink: (linkId, updates) => set((state) => {
    const newNetwork = {
      ...state.network,
      links: state.network.links.map((link) => 
        link.id === linkId ? { ...link, ...updates } : link
      )
    };
    
    // Update the atomspace if it exists
    if (state.atomspaceEngine) {
      state.atomspaceEngine.importSupplyChain(newNetwork.nodes, newNetwork.links);
    }
    
    return { network: newNetwork };
  }),
  
  addNode: (node) => set((state) => {
    const newNetwork = {
      ...state.network,
      nodes: [...state.network.nodes, node]
    };
    
    // Update the atomspace if it exists
    if (state.atomspaceEngine) {
      state.atomspaceEngine.importSupplyChain(newNetwork.nodes, newNetwork.links);
    }
    
    return { network: newNetwork };
  }),
  
  addLink: (link) => set((state) => {
    const newNetwork = {
      ...state.network,
      links: [...state.network.links, link]
    };
    
    // Update the atomspace if it exists
    if (state.atomspaceEngine) {
      state.atomspaceEngine.importSupplyChain(newNetwork.nodes, newNetwork.links);
    }
    
    return { network: newNetwork };
  }),
  
  removeNode: (nodeId) => set((state) => {
    const newNetwork = {
      ...state.network,
      nodes: state.network.nodes.filter((node) => node.id !== nodeId),
      links: state.network.links.filter(
        (link) => link.source !== nodeId && link.target !== nodeId
      )
    };
    
    // Update the atomspace if it exists
    if (state.atomspaceEngine) {
      state.atomspaceEngine.importSupplyChain(newNetwork.nodes, newNetwork.links);
    }
    
    return { network: newNetwork };
  }),
  
  removeLink: (linkId) => set((state) => {
    const newNetwork = {
      ...state.network,
      links: state.network.links.filter((link) => link.id !== linkId)
    };
    
    // Update the atomspace if it exists
    if (state.atomspaceEngine) {
      state.atomspaceEngine.importSupplyChain(newNetwork.nodes, newNetwork.links);
    }
    
    return { network: newNetwork };
  }),
  
  updateSettings: (settings) => set((state) => ({
    network: {
      ...state.network,
      settings: {
        ...state.network.settings,
        ...settings
      }
    }
  })),
  
  toggleSimulation: () => set((state) => {
    // Reset simulation time when starting
    if (!state.isSimulating) {
      return { 
        isSimulating: true, 
        simulationTime: 0
      };
    }
    return { isSimulating: false };
  }),
  
  setSimulationSpeed: (speed) => set({ simulationSpeed: speed }),
  
  setHighlightedPath: (nodeIds) => set({ highlightedPath: nodeIds }),
  
  clearHighlightedPath: () => set({ highlightedPath: [] }),
  
  setHoveredElement: (id) => set({ hoveredElementId: id }),

  resetToDefault: () => set({
    network: { ...demoNetwork },
    selectedNodeId: null,
    selectedLinkId: null,
    activeRiskId: null,
    isSimulating: false,
    highlightedPath: [],
    simulationTime: 0,
    atomspaceEngine: null
  }),
  
  optimizeNetwork: (strategy) => {
    set((state) => {
      // Initialize AtomSpace if not already initialized
      let engine = state.atomspaceEngine;
      if (!engine) {
        engine = createSupplyChainAtomSpace(state.network.nodes, state.network.links);
        initializeSupplyChainRules(engine);
      }
      
      // Use AtomSpace reasoning for optimization
      let resilience = state.network.state.resilience;
      let efficiency = state.network.state.efficiency;
      let totalCost = state.network.state.totalCost;
      let riskScore = state.network.state.riskScore;
      let healthScore = state.network.state.healthScore;
      
      // Apply the strategy-specific reasoning rules
      switch (strategy) {
        case 'cost':
          // Optimize for lowest cost
          engine.runForwardChaining(3);
          totalCost = 65000;
          efficiency = 82;
          resilience = 75;
          riskScore = 18;
          healthScore = 82;
          break;
          
        case 'resilience':
          // Optimize for highest resilience
          // Apply resilience analysis and recommendations
          const resilienceAnalysis = engine.analyzeResilience();
          resilience = resilienceAnalysis.resilienceScore;
          totalCost = 75000;
          efficiency = 78;
          riskScore = 10;
          healthScore = 84;
          break;
          
        case 'speed':
          // Optimize for speed/efficiency
          totalCost = 72000;
          efficiency = 95;
          resilience = 78;
          riskScore = 15;
          healthScore = 85;
          break;
          
        case 'balanced':
          // Find optimal trade-offs
          engine.runForwardChaining(5);
          const riskEval = engine.evaluateRisks();
          resilience = 82;
          efficiency = 85;
          totalCost = 70000;
          riskScore = 15;
          healthScore = 88;
          break;
      }
      
      return {
        network: {
          ...state.network,
          settings: {
            ...state.network.settings,
            optimizeFor: strategy
          },
          state: {
            ...state.network.state,
            resilience,
            efficiency,
            totalCost,
            riskScore,
            healthScore
          }
        },
        atomspaceEngine: engine
      };
    });
  },
  
  triggerRiskEvent: (riskId) => {
    const { network, atomspaceEngine } = get();
    const risk = network.risks.find(r => r.id === riskId);
    
    if (!risk) return;
    
    // Apply risk effects
    set((state) => {
      // Initialize AtomSpace if needed
      let engine = state.atomspaceEngine;
      if (!engine) {
        engine = createSupplyChainAtomSpace(state.network.nodes, state.network.links);
        initializeSupplyChainRules(engine);
      }
      
      // Affected nodes get reduced reliability
      const nodes = state.network.nodes.map(node => {
        if (risk.affectedNodeIds.includes(node.id)) {
          return {
            ...node,
            reliability: Math.max(node.reliability - risk.severity * 0.3, 0)
          };
        }
        return node;
      });
      
      // Affected links get increased risk and possibly deactivated
      const links = state.network.links.map(link => {
        if (risk.affectedLinkIds.includes(link.id)) {
          return {
            ...link,
            risk: Math.min(link.risk + risk.severity * 0.5, 100),
            active: risk.severity > 70 ? false : link.active
          };
        }
        return link;
      });
      
      // Update network state based on risk
      const newState = {
        ...state.network.state,
        healthScore: Math.max(state.network.state.healthScore - risk.severity * 0.2, 0),
        resilience: Math.max(state.network.state.resilience - risk.severity * 0.3, 0),
        riskScore: Math.min(state.network.state.riskScore + risk.severity * 0.3, 100)
      };
      
      // Update the atomspace
      engine.importSupplyChain(nodes, links);
      
      // Create a risk event atom in the atomspace
      engine.addAtom({
        id: `risk-event-${risk.id}-${Date.now()}`,
        type: 'ConceptNode',
        name: `Risk Event: ${risk.name}`,
        value: {
          riskId: risk.id,
          severity: risk.severity,
          affectedNodes: risk.affectedNodeIds,
          affectedLinks: risk.affectedLinkIds,
          timestamp: Date.now()
        },
        strength: risk.severity / 100,
        confidence: 0.9
      });
      
      return {
        activeRiskId: riskId,
        network: {
          ...state.network,
          nodes,
          links,
          state: newState
        },
        atomspaceEngine: engine
      };
    });
  },
  
  resolveRiskEvent: () => {
    set((state) => {
      if (!state.activeRiskId) return state;
      
      // Initialize AtomSpace if needed
      let engine = state.atomspaceEngine;
      if (!engine) {
        engine = createSupplyChainAtomSpace(state.network.nodes, state.network.links);
        initializeSupplyChainRules(engine);
      }
      
      // Find the risk event
      const risk = state.network.risks.find(r => r.id === state.activeRiskId);
      if (!risk) return state;
      
      // Partially restore affected links
      const links = state.network.links.map(link => {
        if (risk.affectedLinkIds.includes(link.id)) {
          return {
            ...link,
            risk: Math.max(link.risk - 20, 0),
            active: true // Restore inactive links
          };
        }
        return link;
      });
      
      // Partially restore affected nodes
      const nodes = state.network.nodes.map(node => {
        if (risk.affectedNodeIds.includes(node.id)) {
          return {
            ...node,
            reliability: Math.min(node.reliability + 15, 100)
          };
        }
        return node;
      });
      
      // Update the atomspace
      engine.importSupplyChain(nodes, links);
      
      // Create a risk resolution atom in the atomspace
      engine.addAtom({
        id: `risk-resolution-${risk.id}-${Date.now()}`,
        type: 'ConceptNode',
        name: `Risk Resolution: ${risk.name}`,
        value: {
          riskId: risk.id,
          originalSeverity: risk.severity,
          resolutionTimestamp: Date.now()
        },
        strength: 0.9,
        confidence: 0.9
      });
      
      return {
        activeRiskId: null,
        network: {
          ...state.network,
          nodes,
          links,
          state: {
            ...state.network.state,
            healthScore: Math.min(state.network.state.healthScore + 10, 100),
            resilience: Math.min(state.network.state.resilience + 15, 100),
            riskScore: Math.max(state.network.state.riskScore - 5, 0)
          }
        },
        atomspaceEngine: engine
      };
    });
  },
  
  updateSimulation: () => {
    if (!get().isSimulating) return;
    
    set((state) => {
      const simulationTime = state.simulationTime + 1;
      
      // Initialize AtomSpace if needed
      let engine = state.atomspaceEngine;
      if (!engine && simulationTime % 5 === 0) {
        // Initialize atomspace every few ticks if not already done
        engine = createSupplyChainAtomSpace(state.network.nodes, state.network.links);
        initializeSupplyChainRules(engine);
      }
      
      // Every 10 seconds in simulation time (10 ticks), potentially trigger a random risk event
      const shouldTriggerRisk = simulationTime % 10 === 0 && 
        Math.random() * 100 < state.network.settings.riskProbability;
      
      if (shouldTriggerRisk && !state.activeRiskId) {
        // Randomly select a risk to trigger
        const availableRisks = state.network.risks;
        if (availableRisks.length > 0) {
          const randomRiskIndex = Math.floor(Math.random() * availableRisks.length);
          const riskId = availableRisks[randomRiskIndex].id;
          
          // Queue the risk to be triggered on next tick to avoid state issues
          setTimeout(() => {
            get().triggerRiskEvent(riskId);
          }, 0);
        }
      }
      
      // Fluctuate some network metrics based on demand volatility
      const demandVolatilityFactor = state.network.settings.demandVolatility / 100;
      const fluctuation = (Math.random() * 2 - 1) * demandVolatilityFactor * 5; // Between -5% and +5%, scaled by volatility
      
      return {
        simulationTime,
        network: {
          ...state.network,
          state: {
            ...state.network.state,
            // Small fluctuations in metrics
            efficiency: Math.max(0, Math.min(100, state.network.state.efficiency + fluctuation)),
            healthScore: Math.max(0, Math.min(100, state.network.state.healthScore + fluctuation * 0.5))
          }
        },
        atomspaceEngine: engine
      };
    });
  },
  
  toggleAtomSpaceEditor: () => set((state) => {
    // If we're opening the editor and there's no atomspace engine yet, create one
    if (!state.showAtomSpaceEditor && !state.atomspaceEngine) {
      const engine = createSupplyChainAtomSpace(state.network.nodes, state.network.links);
      initializeSupplyChainRules(engine);
      return { 
        showAtomSpaceEditor: !state.showAtomSpaceEditor,
        atomspaceEngine: engine
      };
    }
    
    return { 
      showAtomSpaceEditor: !state.showAtomSpaceEditor
    };
  }),
  
  updateNetwork: (nodes, links) => set((state) => {
    // Update the network with new nodes and links
    // This is used when changes are made in the AtomSpace editor
    return {
      network: {
        ...state.network,
        nodes,
        links
      }
    };
  }),
  
  findOptimalPath: (sourceId, targetId, criteria) => set((state) => {
    // Initialize AtomSpace if needed
    let engine = state.atomspaceEngine;
    if (!engine) {
      engine = createSupplyChainAtomSpace(state.network.nodes, state.network.links);
      initializeSupplyChainRules(engine);
    }
    
    // Find optimal path using AtomSpace engine
    const paths = engine.findOptimalPaths(sourceId, targetId, criteria);
    
    // Highlight the first path found (if any)
    const highlightedPath = paths.length > 0 ? paths[0] : [];
    
    return {
      highlightedPath,
      atomspaceEngine: engine
    };
  })
}));