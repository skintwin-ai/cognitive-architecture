import React, { useEffect } from 'react';
import Header from './components/Header';
import NetworkVisualization from './components/NetworkVisualization';
import ControlPanel from './components/ControlPanel';
import AtomSpaceEditor from './components/AtomSpaceEditor';
import { useSupplyChainStore } from './store';

function App() {
  const { network, atomspaceEngine, showAtomSpaceEditor } = useSupplyChainStore();
  
  // Initialize AtomSpace when the app loads
  useEffect(() => {
    const initAtomSpace = async () => {
      // The initialization now happens in the store when needed
    };
    
    initAtomSpace();
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 p-4 md:p-6 font-['Inter',sans-serif]">
      <div className="max-w-7xl mx-auto space-y-6">
        <Header />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <NetworkVisualization />
          </div>
          <div className="lg:col-span-1">
            <ControlPanel />
          </div>
        </div>
        
        <div className="mt-6 text-center text-sm text-gray-500">
          <p>Supply Chain Network Visualization • Powered by AtomSpace • {new Date().getFullYear()}</p>
        </div>
      </div>
      
      {/* AtomSpace Editor Portal */}
      {showAtomSpaceEditor && <AtomSpaceEditor />}
    </div>
  );
}

export default App;