import { 
  Atom, 
  Node, 
  Link, 
  AtomSpace, 
  Pattern, 
  Rule,
  SupplyChainAtomSpace,
  ReasoningResult,
  AtomSpaceEvent,
  AtomSpaceAction,
  AccountNode,
  OrgNode,
  TransactionNode,
  TrialBalanceNode,
  OrgRelationshipLink,
  AccountingEntryLink
} from '../types/atomspace';

/**
 * AtomSpace Engine - Core implementation of the AtomSpace framework
 * Provides functionality for managing atoms, patterns, inference, and attention allocation
 */
export class AtomSpaceEngine {
  private atomspace: SupplyChainAtomSpace;
  private eventListeners: ((event: AtomSpaceEvent) => void)[] = [];
  private reasoningLog: ReasoningResult[] = [];

  constructor(name: string, description?: string) {
    this.atomspace = {
      id: crypto.randomUUID(),
      name,
      description,
      atoms: {},
      nodes: {},
      links: {},
      patterns: {},
      rules: {},
      attention: {
        atoms: [],
        shortTermImportance: {},
        longTermImportance: {}
      }
    };
  }

  // Core AtomSpace methods
  
  /**
   * Add an atom to the atomspace
   */
  addAtom(atom: Atom): Atom {
    // Ensure atom has an ID
    if (!atom.id) {
      atom.id = crypto.randomUUID();
    }

    // Add to the appropriate collections
    this.atomspace.atoms[atom.id] = atom;
    
    if (this.isNode(atom)) {
      this.atomspace.nodes[atom.id] = atom as any;
    } else if (this.isLink(atom)) {
      this.atomspace.links[atom.id] = atom as any;
    }
    
    // Emit event
    this.emitEvent({
      id: crypto.randomUUID(),
      type: 'atom-added',
      timestamp: Date.now(),
      data: { atom }
    });
    
    return atom;
  }
  
  /**
   * Remove an atom from the atomspace
   */
  removeAtom(atomId: string): boolean {
    const atom = this.atomspace.atoms[atomId];
    if (!atom) return false;
    
    // Remove from collections
    delete this.atomspace.atoms[atomId];
    
    if (this.isNode(atom)) {
      delete this.atomspace.nodes[atomId];
    } else if (this.isLink(atom)) {
      delete this.atomspace.links[atomId];
    }
    
    // Emit event
    this.emitEvent({
      id: crypto.randomUUID(),
      type: 'atom-removed',
      timestamp: Date.now(),
      data: { atomId }
    });
    
    return true;
  }
  
  /**
   * Update an atom in the atomspace
   */
  updateAtom(atomId: string, updates: Partial<Atom>): Atom | null {
    const atom = this.atomspace.atoms[atomId];
    if (!atom) return null;
    
    // Apply updates
    const updatedAtom = { ...atom, ...updates };
    this.atomspace.atoms[atomId] = updatedAtom;
    
    if (this.isNode(updatedAtom)) {
      this.atomspace.nodes[atomId] = updatedAtom as any;
    } else if (this.isLink(updatedAtom)) {
      this.atomspace.links[atomId] = updatedAtom as any;
    }
    
    // Emit event
    this.emitEvent({
      id: crypto.randomUUID(),
      type: 'atom-updated',
      timestamp: Date.now(),
      data: { atom: updatedAtom }
    });
    
    return updatedAtom;
  }
  
  /**
   * Get an atom by ID
   */
  getAtom(atomId: string): Atom | null {
    return this.atomspace.atoms[atomId] || null;
  }
  
  /**
   * Get all atoms in the atomspace
   */
  getAllAtoms(): Atom[] {
    return Object.values(this.atomspace.atoms);
  }
  
  /**
   * Get all nodes in the atomspace
   */
  getAllNodes(): Node[] {
    return Object.values(this.atomspace.nodes) as Node[];
  }
  
  /**
   * Get all links in the atomspace
   */
  getAllLinks(): Link[] {
    return Object.values(this.atomspace.links) as Link[];
  }
  
  /**
   * Find atoms by type
   */
  getAtomsByType(type: string): Atom[] {
    return this.getAllAtoms().filter(atom => atom.type === type);
  }
  
  /**
   * Find nodes by node type
   */
  getNodesByType(nodeType: string): Node[] {
    return this.getAllNodes().filter(node => 
      node.type === 'ConceptNode' && (node as any).nodeType === nodeType
    );
  }
  
  /**
   * Find incoming links to a node
   */
  getIncomingLinks(nodeId: string): Link[] {
    return this.getAllLinks().filter(link => 
      link.outgoingSet.includes(nodeId)
    );
  }
  
  /**
   * Find outgoing links from a node
   */
  getOutgoingLinks(nodeId: string): Link[] {
    return this.getAllLinks().filter(link => 
      link.outgoingSet[0] === nodeId
    );
  }
  
  /**
   * Get connected nodes
   */
  getConnectedNodes(nodeId: string): Node[] {
    const connectedNodeIds = new Set<string>();
    
    // Get all links that include this node
    const links = this.getIncomingLinks(nodeId);
    
    // For each link, add all nodes except the source node
    for (const link of links) {
      for (const connectedId of link.outgoingSet) {
        if (connectedId !== nodeId) {
          connectedNodeIds.add(connectedId);
        }
      }
    }
    
    // Convert to array of nodes
    return Array.from(connectedNodeIds).map(id => this.getAtom(id) as Node).filter(Boolean);
  }
  
  // Pattern matching
  
  /**
   * Add a pattern to the atomspace
   */
  addPattern(pattern: Pattern): Pattern {
    if (!pattern.id) {
      pattern.id = crypto.randomUUID();
    }
    
    this.atomspace.patterns[pattern.id] = pattern;
    return pattern;
  }
  
  /**
   * Match a pattern against the atomspace
   */
  matchPattern(patternId: string): Record<string, Atom[]> {
    const pattern = this.atomspace.patterns[patternId];
    if (!pattern) return {};
    
    // Enhanced pattern matching implementation
    
    const bindings: Record<string, Atom[]> = {};
    
    // For each atom in the pattern
    for (const patternAtom of pattern.atoms) {
      if (patternAtom.type === 'VariableNode') {
        // For variable nodes, find all compatible atoms
        const matches = this.getAllAtoms().filter(atom => 
          this.isCompatible(patternAtom, atom)
        );
        
        if (patternAtom.name) {
          bindings[patternAtom.name] = matches;
        }
      }
    }
    
    // Apply constraints between variables if specified in the pattern
    if (pattern.bindingSet) {
      for (const [varName, constrainedVars] of Object.entries(pattern.bindingSet)) {
        if (!bindings[varName]) continue;
        
        // Filter bindings based on constraints
        bindings[varName] = bindings[varName].filter(atom => {
          return constrainedVars.every(constrainedVar => {
            if (!bindings[constrainedVar]) return true;
            
            // Check relationship constraints based on the pattern
            return bindings[constrainedVar].some(otherAtom => 
              this.checkConstraint(atom, otherAtom)
            );
          });
        });
      }
    }
    
    // Emit event
    this.emitEvent({
      id: crypto.randomUUID(),
      type: 'pattern-match',
      timestamp: Date.now(),
      data: { patternId, bindings }
    });
    
    return bindings;
  }
  
  /**
   * Check constraint between two atoms
   * In a more sophisticated implementation, this would handle different types of constraints
   */
  private checkConstraint(atom1: Atom, atom2: Atom): boolean {
    // For links, check if they share nodes
    if (this.isLink(atom1) && this.isLink(atom2)) {
      const link1 = atom1 as Link;
      const link2 = atom2 as Link;
      
      return link1.outgoingSet.some(id => link2.outgoingSet.includes(id));
    }
    
    // For nodes and links
    if (this.isNode(atom1) && this.isLink(atom2)) {
      const link = atom2 as Link;
      return link.outgoingSet.includes(atom1.id);
    }
    
    if (this.isLink(atom1) && this.isNode(atom2)) {
      const link = atom1 as Link;
      return link.outgoingSet.includes(atom2.id);
    }
    
    // Default: no constraint
    return true;
  }
  
  /**
   * Check if two atoms are compatible (for pattern matching)
   */
  private isCompatible(patternAtom: Atom, targetAtom: Atom): boolean {
    // Variable nodes can match any atom of the same basic category
    if (patternAtom.type === 'VariableNode') {
      if (this.isNode(patternAtom) && this.isNode(targetAtom)) {
        return true;
      }
      if (this.isLink(patternAtom) && this.isLink(targetAtom)) {
        return true;
      }
      return false;
    }
    
    // For non-variable nodes, types must match
    if (patternAtom.type !== targetAtom.type) {
      return false;
    }
    
    // For links, check outgoing sets
    if (this.isLink(patternAtom) && this.isLink(targetAtom)) {
      const patternLink = patternAtom as Link;
      const targetLink = targetAtom as Link;
      
      if (patternLink.outgoingSet.length !== targetLink.outgoingSet.length) {
        return false;
      }
      
      // Check each element in the outgoing set
      for (let i = 0; i < patternLink.outgoingSet.length; i++) {
        const patternOutAtomId = patternLink.outgoingSet[i];
        const targetOutAtomId = targetLink.outgoingSet[i];
        
        const patternOutAtom = this.getAtom(patternOutAtomId);
        const targetOutAtom = this.getAtom(targetOutAtomId);
        
        if (!patternOutAtom || !targetOutAtom) {
          return false;
        }
        
        if (!this.isCompatible(patternOutAtom, targetOutAtom)) {
          return false;
        }
      }
    }
    
    return true;
  }
  
  // Rules and inference
  
  /**
   * Add a rule to the atomspace
   */
  addRule(rule: Rule): Rule {
    if (!rule.id) {
      rule.id = crypto.randomUUID();
    }
    
    this.atomspace.rules[rule.id] = rule;
    return rule;
  }
  
  /**
   * Get a rule by ID
   */
  getRule(ruleId: string): Rule | null {
    return this.atomspace.rules[ruleId] || null;
  }
  
  /**
   * Get all rules
   */
  getAllRules(): Rule[] {
    return Object.values(this.atomspace.rules);
  }
  
  /**
   * Apply a rule to derive new atoms
   */
  applyRule(ruleId: string): ReasoningResult | null {
    const rule = this.atomspace.rules[ruleId];
    if (!rule) return null;
    
    // Match the pattern
    const bindings = this.matchPattern(rule.pattern.id);
    
    // Apply the rule's action to generate new atoms
    const derivedAtoms = rule.action(bindings);
    
    // Calculate confidence based on rule cost and input confidences
    const inputAtomIds = Object.values(bindings).flat().map(atom => atom.id);
    const avgConfidence = inputAtomIds.length > 0
      ? inputAtomIds.reduce((sum, id) => {
          const atom = this.getAtom(id);
          return sum + (atom ? atom.confidence : 0);
        }, 0) / inputAtomIds.length
      : 0;
      
    const ruleConfidence = 1 - rule.cost;
    const resultConfidence = avgConfidence * ruleConfidence;
    
    // Add the derived atoms to the atomspace
    const outputAtomIds: string[] = [];
    for (const atom of derivedAtoms) {
      // Set confidence based on rule and input confidences
      atom.confidence = resultConfidence;
      const addedAtom = this.addAtom(atom);
      outputAtomIds.push(addedAtom.id);
    }
    
    // Create the reasoning result
    const result: ReasoningResult = {
      derivedAtoms,
      confidence: resultConfidence,
      steps: [
        {
          ruleId,
          inputAtoms: inputAtomIds,
          outputAtoms: outputAtomIds
        }
      ]
    };
    
    // Add to reasoning log
    this.reasoningLog.push(result);
    
    // Emit event
    this.emitEvent({
      id: crypto.randomUUID(),
      type: 'rule-fired',
      timestamp: Date.now(),
      data: { ruleId, result }
    });
    
    return result;
  }
  
  /**
   * Run forward chaining inference on the atomspace
   * Applies all applicable rules until no new atoms are derived or max iterations reached
   */
  runForwardChaining(maxIterations: number = 10): ReasoningResult[] {
    const results: ReasoningResult[] = [];
    let newAtomsAdded = true;
    let iterations = 0;
    
    const initialAtomCount = Object.keys(this.atomspace.atoms).length;
    
    while (newAtomsAdded && iterations < maxIterations) {
      iterations++;
      newAtomsAdded = false;
      
      // Get all rules
      const rules = this.getAllRules();
      
      // Sort rules by cost (apply lowest cost rules first)
      rules.sort((a, b) => a.cost - b.cost);
      
      for (const rule of rules) {
        const result = this.applyRule(rule.id);
        
        if (result && result.derivedAtoms.length > 0) {
          newAtomsAdded = true;
          results.push(result);
        }
      }
    }
    
    const finalAtomCount = Object.keys(this.atomspace.atoms).length;
    console.log(`Forward chaining completed in ${iterations} iterations. Added ${finalAtomCount - initialAtomCount} new atoms.`);
    
    return results;
  }
  
  /**
   * Get the reasoning log
   */
  getReasoningLog(): ReasoningResult[] {
    return this.reasoningLog;
  }
  
  /**
   * Clear the reasoning log
   */
  clearReasoningLog(): void {
    this.reasoningLog = [];
  }
  
  // Attention allocation
  
  /**
   * Update attention values for atoms
   */
  updateAttention(atomId: string, sti: number, lti: number): void {
    if (!this.atomspace.atoms[atomId]) return;
    
    this.atomspace.attention.shortTermImportance[atomId] = sti;
    this.atomspace.attention.longTermImportance[atomId] = lti;
    
    // Update the attentional focus based on STI values
    this.recalculateAttentionalFocus();
  }
  
  /**
   * Recalculate which atoms are in the attentional focus
   */
  private recalculateAttentionalFocus(): void {
    // Sort atoms by STI and take the top 10%
    const allAtomIds = Object.keys(this.atomspace.atoms);
    const sortedBySTI = allAtomIds.sort((a, b) => {
      const stiA = this.atomspace.attention.shortTermImportance[a] || 0;
      const stiB = this.atomspace.attention.shortTermImportance[b] || 0;
      return stiB - stiA; // Descending order
    });
    
    const topN = Math.max(1, Math.ceil(allAtomIds.length * 0.1));
    this.atomspace.attention.atoms = sortedBySTI.slice(0, topN);
  }
  
  /**
   * Spread activation through the network
   */
  spreadActivation(initialAtomId: string, amount: number, decay: number = 0.5): void {
    // Get the initial atom
    const atom = this.getAtom(initialAtomId);
    if (!atom) return;
    
    // Set the initial STI
    this.updateAttention(
      initialAtomId,
      (this.atomspace.attention.shortTermImportance[initialAtomId] || 0) + amount,
      this.atomspace.attention.longTermImportance[initialAtomId] || 0
    );
    
    // For each connected atom, spread activation recursively
    if (this.isLink(atom)) {
      const link = atom as Link;
      for (const connectedId of link.outgoingSet) {
        this.spreadActivation(connectedId, amount * decay, decay);
      }
    } else {
      // Find links that contain this node
      const connectedLinks = Object.values(this.atomspace.links).filter(link => 
        link.outgoingSet.includes(initialAtomId)
      );
      
      for (const link of connectedLinks) {
        this.spreadActivation(link.id, amount * decay, decay);
        
        // Spread to other nodes in the link
        for (const connectedId of link.outgoingSet) {
          if (connectedId !== initialAtomId) {
            this.spreadActivation(connectedId, amount * decay * decay, decay);
          }
        }
      }
    }
  }
  
  /**
   * Get atoms in attentional focus
   */
  getAttentionalFocus(): Atom[] {
    return this.atomspace.attention.atoms.map(id => this.getAtom(id)).filter(Boolean) as Atom[];
  }
  
  // Utility methods
  
  /**
   * Check if an atom is a node
   */
  isNode(atom: Atom): boolean {
    return ['ConceptNode', 'PredicateNode', 'VariableNode'].includes(atom.type);
  }
  
  /**
   * Check if an atom is a link
   */
  isLink(atom: Atom): boolean {
    return ['EvaluationLink', 'InheritanceLink', 'MemberLink', 'AndLink', 'OrLink', 'NotLink'].includes(atom.type);
  }
  
  /**
   * Add an event listener
   */
  addEventListener(callback: (event: AtomSpaceEvent) => void): void {
    this.eventListeners.push(callback);
  }
  
  /**
   * Remove an event listener
   */
  removeEventListener(callback: (event: AtomSpaceEvent) => void): void {
    this.eventListeners = this.eventListeners.filter(listener => listener !== callback);
  }
  
  /**
   * Emit an event to all listeners
   */
  private emitEvent(event: AtomSpaceEvent): void {
    for (const listener of this.eventListeners) {
      listener(event);
    }
  }
  
  // Supply Chain specific methods
  
  /**
   * Convert supply chain data to atomspace representation
   */
  importSupplyChain(nodes: any[], links: any[]): void {
    // Clear existing atoms
    this.atomspace.atoms = {};
    this.atomspace.nodes = {};
    this.atomspace.links = {};
    
    // Import nodes
    for (const nodeData of nodes) {
      const node: SupplyChainNode = {
        id: nodeData.id,
        type: 'ConceptNode',
        nodeType: nodeData.type,
        name: nodeData.name,
        location: nodeData.location,
        capacity: nodeData.capacity,
        reliability: nodeData.reliability,
        coordinates: nodeData.coordinates,
        strength: nodeData.reliability / 100,
        confidence: 0.9  // High confidence in node data
      };
      
      this.addAtom(node);
    }
    
    // Import links
    for (const linkData of links) {
      // Determine relationship type based on source and target node types
      const sourceNode = this.atomspace.nodes[linkData.source] as SupplyChainNode;
      const targetNode = this.atomspace.nodes[linkData.target] as SupplyChainNode;
      
      let relationshipType: 'supplies' | 'produces' | 'distributes' | 'sells' = 'supplies';
      
      if (sourceNode && targetNode) {
        if (sourceNode.nodeType === 'supplier' && targetNode.nodeType === 'manufacturer') {
          relationshipType = 'supplies';
        } else if (sourceNode.nodeType === 'manufacturer' && targetNode.nodeType === 'distributor') {
          relationshipType = 'produces';
        } else if (sourceNode.nodeType === 'distributor' && targetNode.nodeType === 'retailer') {
          relationshipType = 'distributes';
        } else if (sourceNode.nodeType === 'retailer' && targetNode.nodeType === 'customer') {
          relationshipType = 'sells';
        }
      }
      
      const link: SupplyChainLink = {
        id: linkData.id,
        type: 'EvaluationLink',
        relationshipType,
        outgoingSet: [linkData.source, linkData.target],
        material: linkData.material,
        quantity: linkData.quantity,
        leadTime: linkData.leadTime,
        cost: linkData.cost,
        risk: linkData.risk,
        active: linkData.active,
        strength: (100 - linkData.risk) / 100,  // Inverse of risk
        confidence: 0.8  // Slightly lower confidence for links
      };
      
      this.addAtom(link);
    }
    
    // After importing, add additional atoms for supply chain analysis
    this.createSupplyChainMetaAtoms();
  }
  
  /**
   * Create additional atoms for supply chain meta-analysis
   * These include:
   * - Category nodes for node types
   * - Supply chain metrics
   * - Risk assessments
   */
  private createSupplyChainMetaAtoms(): void {
    // Create category nodes for each node type
    const nodeTypes = ['supplier', 'manufacturer', 'distributor', 'retailer', 'customer'];
    
    for (const type of nodeTypes) {
      this.addAtom({
        id: `category-${type}`,
        type: 'ConceptNode',
        name: `${type.charAt(0).toUpperCase() + type.slice(1)} Category`,
        strength: 1.0,
        confidence: 1.0
      });
      
      // Create inheritance links for each node of this type
      const nodesOfType = this.getNodesByType(type);
      for (const node of nodesOfType) {
        this.addAtom({
          id: `inheritance-${node.id}-${type}`,
          type: 'InheritanceLink',
          outgoingSet: [node.id, `category-${type}`],
          strength: 1.0,
          confidence: 0.9
        } as Link);
      }
    }
    
    // Create predicate nodes for risk assessment
    this.addAtom({
      id: 'predicate-high-risk',
      type: 'PredicateNode',
      name: 'HighRisk',
      strength: 1.0,
      confidence: 1.0
    });
    
    this.addAtom({
      id: 'predicate-bottleneck',
      type: 'PredicateNode',
      name: 'Bottleneck',
      strength: 1.0,
      confidence: 1.0
    });
    
    // Identify high-risk links
    const highRiskLinks = Object.values(this.atomspace.links).filter(link => 
      link.risk > 60
    );
    
    // Create evaluation links for high-risk assessments
    for (const link of highRiskLinks) {
      this.addAtom({
        id: `eval-high-risk-${link.id}`,
        type: 'EvaluationLink',
        outgoingSet: ['predicate-high-risk', link.id],
        strength: link.risk / 100,
        confidence: 0.8
      } as Link);
    }
    
    // Create predicate for critical paths
    this.addAtom({
      id: 'predicate-critical-path',
      type: 'PredicateNode',
      name: 'CriticalPath',
      strength: 1.0,
      confidence: 1.0
    });
    
    // Additional meta-atoms would be created by rules during reasoning
  }
  
  /**
   * Export atomspace data to supply chain format
   */
  exportSupplyChain(): { nodes: any[], links: any[] } {
    const nodes = Object.values(this.atomspace.nodes)
      .filter(node => node.nodeType) // Only export nodes that have a nodeType (supply chain nodes)
      .map(node => ({
        id: node.id,
        type: node.nodeType,
        name: node.name,
        location: node.location,
        capacity: node.capacity,
        reliability: node.reliability,
        coordinates: node.coordinates
      }));
    
    const links = Object.values(this.atomspace.links)
      .filter(link => link.relationshipType) // Only export links that have a relationshipType (supply chain links)
      .map(link => ({
        id: link.id,
        source: link.outgoingSet[0],
        target: link.outgoingSet[1],
        material: link.material,
        quantity: link.quantity,
        leadTime: link.leadTime,
        cost: link.cost,
        risk: link.risk,
        active: link.active
      }));
    
    return { nodes, links };
  }
  
  /**
   * Find optimal paths in the supply chain
   */
  findOptimalPaths(
    startNodeId: string, 
    endNodeId: string,
    optimizeFor: 'cost' | 'time' | 'risk' | 'balanced'
  ): string[][] {
    // Get all nodes and links
    const nodes = this.getAllNodes();
    const links = this.getAllLinks();
    
    // Build adjacency list
    const adjacencyList: Record<string, { id: string, cost: number, time: number, risk: number }[]> = {};
    
    // Initialize adjacency list for all nodes
    for (const node of nodes) {
      adjacencyList[node.id] = [];
    }
    
    // Populate adjacency list with links
    for (const link of links) {
      if (this.isLink(link)) {
        const typedLink = link as Link;
        if (typedLink.outgoingSet.length >= 2) {
          const [source, target] = typedLink.outgoingSet;
          
          // Skip inactive links
          if (!(link as any).active) continue;
          
          // Add edge to adjacency list
          adjacencyList[source].push({
            id: target,
            cost: (link as any).cost || 0,
            time: (link as any).leadTime || 0,
            risk: (link as any).risk || 0
          });
        }
      }
    }
    
    // Dijkstra's algorithm to find shortest path
    const distances: Record<string, number> = {};
    const previous: Record<string, string | null> = {};
    const visited: Set<string> = new Set();
    
    // Initialize distances
    for (const nodeId in adjacencyList) {
      distances[nodeId] = Infinity;
      previous[nodeId] = null;
    }
    
    // Start node has distance 0
    distances[startNodeId] = 0;
    
    // Helper function to get cost metric based on optimization strategy
    const getCostMetric = (edge: { cost: number, time: number, risk: number }): number => {
      switch (optimizeFor) {
        case 'cost':
          return edge.cost;
        case 'time':
          return edge.time;
        case 'risk':
          return edge.risk;
        case 'balanced':
          return (edge.cost / 1000) + edge.time + (edge.risk / 10); // Normalize and combine
        default:
          return edge.cost;
      }
    };
    
    // Find the shortest path
    while (visited.size < Object.keys(adjacencyList).length) {
      // Find unvisited node with smallest distance
      let minDistance = Infinity;
      let currentNode = null;
      
      for (const nodeId in distances) {
        if (!visited.has(nodeId) && distances[nodeId] < minDistance) {
          minDistance = distances[nodeId];
          currentNode = nodeId;
        }
      }
      
      if (currentNode === null || currentNode === endNodeId) {
        break;
      }
      
      visited.add(currentNode);
      
      // Update distances to neighbors
      for (const neighbor of adjacencyList[currentNode]) {
        if (!visited.has(neighbor.id)) {
          const cost = getCostMetric(neighbor);
          const newDistance = distances[currentNode] + cost;
          
          if (newDistance < distances[neighbor.id]) {
            distances[neighbor.id] = newDistance;
            previous[neighbor.id] = currentNode;
          }
        }
      }
    }
    
    // Reconstruct the path
    const path: string[] = [];
    let current = endNodeId;
    
    if (previous[current] === null && current !== startNodeId) {
      return []; // No path found
    }
    
    while (current !== null) {
      path.unshift(current);
      current = previous[current]!;
    }
    
    // Create a critical path evaluation link in the atomspace
    if (path.length > 1) {
      this.addAtom({
        id: `critical-path-${startNodeId}-${endNodeId}`,
        type: 'EvaluationLink',
        outgoingSet: ['predicate-critical-path', ...path],
        strength: 0.9,
        confidence: 0.85
      } as Link);
    }
    
    return [path];
  }
  
  /**
   * Evaluate risks in the supply chain
   */
  evaluateRisks(): {
    overallRisk: number,
    criticalNodes: string[],
    criticalLinks: string[]
  } {
    const nodes = Object.values(this.atomspace.nodes);
    const links = Object.values(this.atomspace.links);
    
    // Identify critical nodes based on:
    // 1. Low reliability (< 80%)
    // 2. High centrality (degree > 3)
    // 3. Bottlenecks (node with high in-degree and out-degree)
    
    // Calculate node degrees
    const inDegree: Record<string, number> = {};
    const outDegree: Record<string, number> = {};
    
    for (const link of links) {
      if (link.outgoingSet.length >= 2) {
        const source = link.outgoingSet[0];
        const target = link.outgoingSet[1];
        
        outDegree[source] = (outDegree[source] || 0) + 1;
        inDegree[target] = (inDegree[target] || 0) + 1;
      }
    }
    
    // Identify bottlenecks (nodes with high combined degree)
    const bottleneckThreshold = 3;
    const bottlenecks = nodes.filter(node => 
      (inDegree[node.id] || 0) >= 1 && 
      (outDegree[node.id] || 0) >= 1 &&
      (inDegree[node.id] || 0) + (outDegree[node.id] || 0) >= bottleneckThreshold
    );
    
    // Create bottleneck evaluations in the atomspace
    for (const node of bottlenecks) {
      this.addAtom({
        id: `eval-bottleneck-${node.id}`,
        type: 'EvaluationLink',
        outgoingSet: ['predicate-bottleneck', node.id],
        strength: 0.9,
        confidence: 0.8
      } as Link);
    }
    
    // Nodes with low reliability or high centrality are critical
    const criticalNodes = nodes
      .filter(node => 
        node.reliability < 80 || 
        (inDegree[node.id] || 0) + (outDegree[node.id] || 0) > 3 ||
        bottlenecks.some(b => b.id === node.id)
      )
      .map(node => node.id);
    
    // Links with high risk are critical
    const criticalLinks = links
      .filter(link => link.risk > 60)
      .map(link => link.id);
    
    // Calculate overall risk as a weighted average of:
    // 1. Node risk (based on reliability)
    // 2. Link risk
    // 3. Network topology risk (based on critical nodes and links)
    
    const nodeRiskSum = nodes.reduce((sum, node) => sum + (100 - node.reliability), 0);
    const linkRiskSum = links.reduce((sum, link) => sum + link.risk, 0);
    
    const nodeRiskAvg = nodeRiskSum / nodes.length;
    const linkRiskAvg = linkRiskSum / links.length;
    
    // Topology risk based on percentage of critical elements
    const topologyRisk = 
      ((criticalNodes.length / nodes.length) + (criticalLinks.length / links.length)) * 50;
    
    const overallRisk = (nodeRiskAvg * 0.3) + (linkRiskAvg * 0.5) + (topologyRisk * 0.2);
    
    return {
      overallRisk,
      criticalNodes,
      criticalLinks
    };
  }
  
  /**
   * Analyze resilience of the supply chain network
   */
  analyzeResilience(): {
    resilienceScore: number,
    vulnerablePoints: string[],
    recommendedImprovements: string[]
  } {
    const nodes = Object.values(this.atomspace.nodes);
    const links = Object.values(this.atomspace.links);
    
    // Calculate network metrics
    const { criticalNodes, criticalLinks } = this.evaluateRisks();
    
    // Analyze network structure for resilience
    // 1. Check for alternative paths between critical nodes
    // 2. Identify single points of failure
    // 3. Evaluate supplier diversity
    
    // Identify single points of failure (nodes that, if removed, would disconnect the network)
    const singlePointsOfFailure: string[] = [];
    
    for (const node of nodes) {
      // Skip end points (suppliers and customers)
      if (node.nodeType === 'supplier' || node.nodeType === 'customer') {
        continue;
      }
      
      // Check if removing this node would disconnect parts of the network
      // This is a simplified approach - a full implementation would use more sophisticated
      // graph theory algorithms
      
      const incomingLinks = links.filter(link => link.outgoingSet[1] === node.id);
      const outgoingLinks = links.filter(link => link.outgoingSet[0] === node.id);
      
      // If this node is the only connection between upstream and downstream nodes
      if (incomingLinks.length === 1 && outgoingLinks.length >= 1) {
        singlePointsOfFailure.push(node.id);
      }
      
      if (incomingLinks.length >= 1 && outgoingLinks.length === 1) {
        singlePointsOfFailure.push(node.id);
      }
    }
    
    // Analyze supplier diversity
    // Count how many manufacturers are supplied by multiple suppliers
    const manufacturerNodes = nodes.filter(node => node.nodeType === 'manufacturer');
    
    let manufacturersWithMultipleSuppliers = 0;
    for (const manufacturer of manufacturerNodes) {
      const supplierLinks = links.filter(link => 
        link.outgoingSet[1] === manufacturer.id && 
        nodes.find(n => n.id === link.outgoingSet[0])?.nodeType === 'supplier'
      );
      
      if (supplierLinks.length > 1) {
        manufacturersWithMultipleSuppliers++;
      }
    }
    
    const supplierDiversityRatio = manufacturersWithMultipleSuppliers / manufacturerNodes.length;
    
    // Calculate resilience score
    // Lower percentage of critical nodes/links = higher resilience
    const criticalNodeRatio = criticalNodes.length / nodes.length;
    const criticalLinkRatio = criticalLinks.length / links.length;
    const singlePointRatio = singlePointsOfFailure.length / nodes.length;
    
    // Calculate resilience score (higher is better)
    const resilienceScore = Math.round(
      (1 - criticalNodeRatio * 0.3) * 
      (1 - criticalLinkRatio * 0.3) * 
      (1 - singlePointRatio * 0.2) * 
      (0.5 + supplierDiversityRatio * 0.5) * 
      100
    );
    
    // Combine vulnerable points
    const vulnerablePoints = [...new Set([...criticalNodes, ...singlePointsOfFailure])];
    
    // Generate recommendations
    const recommendedImprovements: string[] = [];
    
    if (criticalNodeRatio > 0.2) {
      recommendedImprovements.push("Increase reliability of critical nodes");
    }
    
    if (criticalLinkRatio > 0.2) {
      recommendedImprovements.push("Reduce risk levels in critical links");
    }
    
    if (singlePointRatio > 0.1) {
      recommendedImprovements.push("Add redundant paths around single points of failure");
    }
    
    if (supplierDiversityRatio < 0.5) {
      recommendedImprovements.push("Increase supplier diversity for manufacturers");
    }
    
    return {
      resilienceScore,
      vulnerablePoints,
      recommendedImprovements
    };
  }
  
  /**
   * Calculate network centrality measures
   */
  calculateCentrality(): Record<string, { degree: number, betweenness: number }> {
    const nodes = this.getAllNodes();
    const links = this.getAllLinks();
    const centrality: Record<string, { degree: number, betweenness: number }> = {};
    
    // Initialize centrality measures
    for (const node of nodes) {
      centrality[node.id] = { degree: 0, betweenness: 0 };
    }
    
    // Calculate degree centrality (number of connections)
    for (const link of links) {
      for (const nodeId of link.outgoingSet) {
        centrality[nodeId].degree = (centrality[nodeId].degree || 0) + 1;
      }
    }
    
    // For a full implementation, betweenness centrality would require computing
    // all shortest paths between all pairs of nodes.
    // This is a simplified approximation based on node positions in the supply chain
    
    // Nodes in the middle of the supply chain (manufacturers, distributors) typically
    // have higher betweenness centrality
    for (const node of nodes) {
      if ((node as any).nodeType === 'manufacturer' || (node as any).nodeType === 'distributor') {
        centrality[node.id].betweenness = 10;
      } else {
        centrality[node.id].betweenness = 5;
      }
    }
    
    // Adjust betweenness based on degree - nodes with more connections are likely
    // to be on more shortest paths
    for (const nodeId in centrality) {
      centrality[nodeId].betweenness *= (centrality[nodeId].degree / 5);
    }
    
    return centrality;
  }
  
  // Organization and Accounting specific methods
  
  /**
   * Create a new organization in the atomspace
   */
  createOrganization(orgData: Partial<OrgNode>): OrgNode {
    const orgId = orgData.id || `org-${crypto.randomUUID()}`;
    
    const organization: OrgNode = {
      id: orgId,
      type: 'ConceptNode',
      nodeType: 'organization',
      orgName: orgData.orgName || 'New Organization',
      legalStructure: orgData.legalStructure || 'corporation',
      fiscalYear: orgData.fiscalYear || { startMonth: 1, startDay: 1 },
      industry: orgData.industry,
      dateEstablished: orgData.dateEstablished,
      strength: 1.0,
      confidence: 1.0
    };
    
    return this.addAtom(organization) as OrgNode;
  }
  
  /**
   * Create a chart of accounts for an organization
   */
  createChartOfAccounts(orgId: string, accounts: Partial<AccountNode>[]): AccountNode[] {
    const createdAccounts: AccountNode[] = [];
    
    // Create a structure for the chart of accounts
    this.addAtom({
      id: `chart-of-accounts-${orgId}`,
      type: 'ConceptNode',
      name: 'Chart of Accounts',
      strength: 1.0,
      confidence: 1.0
    });
    
    // Link chart of accounts to organization
    this.addAtom({
      id: `org-has-coa-${orgId}`,
      type: 'EvaluationLink',
      relationshipType: 'owns',
      outgoingSet: [orgId, `chart-of-accounts-${orgId}`],
      strength: 1.0,
      confidence: 1.0
    } as OrgRelationshipLink);
    
    // Create account hierarchy
    for (const acctData of accounts) {
      const accountId = acctData.id || `account-${crypto.randomUUID()}`;
      
      const account: AccountNode = {
        id: accountId,
        type: 'ConceptNode',
        nodeType: 'account',
        accountNumber: acctData.accountNumber || '',
        accountName: acctData.accountName || '',
        accountType: acctData.accountType || 'asset',
        subType: acctData.subType,
        balance: acctData.balance || 0,
        currency: acctData.currency || 'USD',
        isDebit: acctData.isDebit !== undefined ? acctData.isDebit : true,
        parentAccount: acctData.parentAccount,
        metadata: acctData.metadata,
        tags: acctData.tags,
        strength: 1.0,
        confidence: 1.0
      };
      
      this.addAtom(account);
      createdAccounts.push(account);
      
      // Link account to chart of accounts
      this.addAtom({
        id: `coa-contains-${accountId}`,
        type: 'MemberLink',
        outgoingSet: [`chart-of-accounts-${orgId}`, accountId],
        strength: 1.0,
        confidence: 1.0
      } as Link);
      
      // If there's a parent account, create a hierarchy link
      if (account.parentAccount) {
        this.addAtom({
          id: `account-hierarchy-${account.parentAccount}-${accountId}`,
          type: 'InheritanceLink',
          outgoingSet: [accountId, account.parentAccount],
          strength: 1.0,
          confidence: 1.0
        } as Link);
      }
    }
    
    return createdAccounts;
  }
  
  /**
   * Create a trial balance for an organization
   */
  createTrialBalance(orgId: string, asOfDate: string): TrialBalanceNode {
    // Collect all accounts for this organization
    const chartOfAccountsId = `chart-of-accounts-${orgId}`;
    const coaLinks = this.getAllLinks().filter(link => 
      link.type === 'MemberLink' && link.outgoingSet[0] === chartOfAccountsId
    );
    
    const accountIds = coaLinks.map(link => link.outgoingSet[1]);
    const accounts = accountIds.map(id => this.getAtom(id) as AccountNode).filter(Boolean);
    
    // Calculate totals
    let totalDebits = 0;
    let totalCredits = 0;
    
    for (const account of accounts) {
      if (account.isDebit && account.balance > 0) {
        totalDebits += account.balance;
      } else if (!account.isDebit && account.balance > 0) {
        totalCredits += account.balance;
      } else if (account.isDebit && account.balance < 0) {
        totalCredits += Math.abs(account.balance);
      } else if (!account.isDebit && account.balance < 0) {
        totalDebits += Math.abs(account.balance);
      }
    }
    
    // Create trial balance node
    const trialBalanceId = `trial-balance-${orgId}-${asOfDate}`;
    const trialBalance: TrialBalanceNode = {
      id: trialBalanceId,
      type: 'ConceptNode',
      nodeType: 'trialBalance',
      name: `Trial Balance as of ${asOfDate}`,
      asOfDate,
      status: 'draft',
      totalDebits,
      totalCredits,
      isBalanced: Math.abs(totalDebits - totalCredits) < 0.01,
      currency: 'USD', // Default currency
      strength: 1.0,
      confidence: 1.0
    };
    
    this.addAtom(trialBalance);
    
    // Link trial balance to organization
    this.addAtom({
      id: `org-has-tb-${orgId}-${asOfDate}`,
      type: 'EvaluationLink',
      relationshipType: 'owns',
      outgoingSet: [orgId, trialBalanceId],
      strength: 1.0,
      confidence: 1.0
    } as OrgRelationshipLink);
    
    // Link trial balance to accounts
    for (const accountId of accountIds) {
      this.addAtom({
        id: `tb-includes-${trialBalanceId}-${accountId}`,
        type: 'EvaluationLink',
        relationshipType: 'includes',
        outgoingSet: [trialBalanceId, accountId],
        strength: 1.0,
        confidence: 1.0
      } as OrgRelationshipLink);
    }
    
    return trialBalance;
  }
  
  /**
   * Record a transaction in the accounting system
   */
  recordTransaction(
    orgId: string,
    transaction: Partial<TransactionNode>,
    entries: { accountId: string, isDebit: boolean, amount: number }[]
  ): TransactionNode {
    // Create transaction node
    const transactionId = transaction.id || `transaction-${crypto.randomUUID()}`;
    const transactionNode: TransactionNode = {
      id: transactionId,
      type: 'ConceptNode',
      nodeType: 'transaction',
      name: transaction.description || 'New Transaction',
      transactionDate: transaction.transactionDate || new Date().toISOString().split('T')[0],
      postingDate: transaction.postingDate,
      description: transaction.description || '',
      amount: entries.reduce((sum, entry) => sum + entry.amount, 0) / 2, // Total of debits or credits
      currency: transaction.currency || 'USD',
      status: transaction.status || 'pending',
      reference: transaction.reference,
      metadata: transaction.metadata,
      strength: 1.0,
      confidence: 1.0
    };
    
    this.addAtom(transactionNode);
    
    // Link transaction to organization
    this.addAtom({
      id: `org-has-transaction-${orgId}-${transactionId}`,
      type: 'EvaluationLink',
      relationshipType: 'owns',
      outgoingSet: [orgId, transactionId],
      strength: 1.0,
      confidence: 1.0
    } as OrgRelationshipLink);
    
    // Create accounting entries
    let totalDebits = 0;
    let totalCredits = 0;
    
    for (const entry of entries) {
      const entryId = `entry-${crypto.randomUUID()}`;
      const entryType = entry.isDebit ? 'debit' : 'credit';
      
      // Update account balance
      const account = this.getAtom(entry.accountId) as AccountNode;
      if (account) {
        const balanceChange = entry.isDebit 
          ? entry.amount 
          : -entry.amount;
          
        // If account is normally credit and this is a credit, increase the balance
        // If account is normally debit and this is a debit, increase the balance
        // Otherwise, decrease the balance
        const newBalance = account.isDebit === entry.isDebit 
          ? account.balance + entry.amount
          : account.balance - entry.amount;
          
        this.updateAtom(entry.accountId, { ...account, balance: newBalance });
      }
      
      // Track totals for balancing
      if (entry.isDebit) {
        totalDebits += entry.amount;
      } else {
        totalCredits += entry.amount;
      }
      
      // Create entry link
      this.addAtom({
        id: entryId,
        type: 'EvaluationLink',
        relationshipType: entryType as 'debit' | 'credit',
        outgoingSet: [transactionId, entry.accountId],
        amount: entry.amount,
        currency: transaction.currency || 'USD',
        date: transactionNode.transactionDate,
        strength: 1.0,
        confidence: 1.0
      } as AccountingEntryLink);
    }
    
    // Verify that debits equal credits
    if (Math.abs(totalDebits - totalCredits) > 0.01) {
      // Transaction is unbalanced - add a warning
      this.addAtom({
        id: `warning-unbalanced-${transactionId}`,
        type: 'EvaluationLink',
        outgoingSet: ['predicate-high-risk', transactionId],
        name: 'Unbalanced Transaction Warning',
        strength: 0.9,
        confidence: 0.9,
        value: {
          type: 'unbalanced_transaction',
          severity: 'high',
          message: `Transaction is unbalanced: Debits: ${totalDebits}, Credits: ${totalCredits}, Difference: ${totalDebits - totalCredits}`,
        }
      } as Link);
      
      // Update transaction status
      this.updateAtom(transactionId, {
        ...transactionNode,
        status: 'pending',
        metadata: {
          ...transactionNode.metadata,
          isBalanced: false,
          balanceDifference: totalDebits - totalCredits
        }
      });
    } else {
      // Transaction is balanced - update status if it was pending
      if (transactionNode.status === 'pending') {
        this.updateAtom(transactionId, {
          ...transactionNode,
          status: 'posted',
          metadata: {
            ...transactionNode.metadata,
            isBalanced: true
          }
        });
      }
    }
    
    return transactionNode;
  }
  
  /**
   * Generate financial statements from the trial balance
   */
  generateFinancialStatements(trialBalanceId: string): {
    incomeStatement: any,
    balanceSheet: any
  } {
    // Get the trial balance
    const trialBalance = this.getAtom(trialBalanceId) as TrialBalanceNode;
    if (!trialBalance || trialBalance.nodeType !== 'trialBalance') {
      throw new Error('Invalid trial balance ID');
    }
    
    // Get all accounts included in this trial balance
    const tbLinks = this.getAllLinks().filter(link => 
      link.type === 'EvaluationLink' && 
      (link as OrgRelationshipLink).relationshipType === 'includes' &&
      link.outgoingSet[0] === trialBalanceId
    );
    
    const accountIds = tbLinks.map(link => link.outgoingSet[1]);
    const accounts = accountIds.map(id => this.getAtom(id) as AccountNode).filter(Boolean);
    
    // Categorize accounts
    const assetAccounts = accounts.filter(acct => acct.accountType === 'asset');
    const liabilityAccounts = accounts.filter(acct => acct.accountType === 'liability');
    const equityAccounts = accounts.filter(acct => acct.accountType === 'equity');
    const revenueAccounts = accounts.filter(acct => acct.accountType === 'revenue');
    const expenseAccounts = accounts.filter(acct => acct.accountType === 'expense');
    
    // Calculate totals
    const totalAssets = assetAccounts.reduce((sum, acct) => sum + acct.balance, 0);
    const totalLiabilities = liabilityAccounts.reduce((sum, acct) => sum + acct.balance, 0);
    const totalEquity = equityAccounts.reduce((sum, acct) => sum + acct.balance, 0);
    const totalRevenue = revenueAccounts.reduce((sum, acct) => sum + acct.balance, 0);
    const totalExpenses = expenseAccounts.reduce((sum, acct) => sum + acct.balance, 0);
    const netIncome = totalRevenue - totalExpenses;
    
    // Create financial statement atoms
    const incomeStatementId = `income-statement-${trialBalance.asOfDate}`;
    const balanceSheetId = `balance-sheet-${trialBalance.asOfDate}`;
    
    const incomeStatement = {
      id: incomeStatementId,
      type: 'ConceptNode',
      name: `Income Statement as of ${trialBalance.asOfDate}`,
      value: {
        asOfDate: trialBalance.asOfDate,
        currency: trialBalance.currency,
        revenues: revenueAccounts.map(acct => ({
          account: acct.accountName,
          accountId: acct.id,
          amount: acct.balance
        })),
        expenses: expenseAccounts.map(acct => ({
          account: acct.accountName,
          accountId: acct.id,
          amount: acct.balance
        })),
        totalRevenue,
        totalExpenses,
        netIncome
      },
      strength: 1.0,
      confidence: 0.9
    };
    
    const balanceSheet = {
      id: balanceSheetId,
      type: 'ConceptNode',
      name: `Balance Sheet as of ${trialBalance.asOfDate}`,
      value: {
        asOfDate: trialBalance.asOfDate,
        currency: trialBalance.currency,
        assets: assetAccounts.map(acct => ({
          account: acct.accountName,
          accountId: acct.id,
          amount: acct.balance
        })),
        liabilities: liabilityAccounts.map(acct => ({
          account: acct.accountName,
          accountId: acct.id,
          amount: acct.balance
        })),
        equity: equityAccounts.map(acct => ({
          account: acct.accountName,
          accountId: acct.id,
          amount: acct.balance
        })),
        totalAssets,
        totalLiabilities,
        totalEquity,
        isBalanced: Math.abs(totalAssets - (totalLiabilities + totalEquity)) < 0.01
      },
      strength: 1.0,
      confidence: 0.9
    };
    
    // Add financial statements to atomspace
    this.addAtom(incomeStatement);
    this.addAtom(balanceSheet);
    
    // Link financial statements to trial balance
    this.addAtom({
      id: `tb-generates-is-${trialBalanceId}`,
      type: 'EvaluationLink',
      relationshipType: 'produces',
      outgoingSet: [trialBalanceId, incomeStatementId],
      strength: 1.0,
      confidence: 1.0
    } as OrgRelationshipLink);
    
    this.addAtom({
      id: `tb-generates-bs-${trialBalanceId}`,
      type: 'EvaluationLink',
      relationshipType: 'produces',
      outgoingSet: [trialBalanceId, balanceSheetId],
      strength: 1.0,
      confidence: 1.0
    } as OrgRelationshipLink);
    
    return {
      incomeStatement: incomeStatement.value,
      balanceSheet: balanceSheet.value
    };
  }
}

/**
 * Create a new supply chain atomspace from existing network data
 */
export const createSupplyChainAtomSpace = (
  nodes: any[],
  links: any[]
): AtomSpaceEngine => {
  const atomspace = new AtomSpaceEngine("Supply Chain Network", "Knowledge representation of supply chain entities and relationships");
  
  atomspace.importSupplyChain(nodes, links);
  
  return atomspace;
};

/**
 * Initialize default reasoning rules for supply chain analysis
 */
export const initializeSupplyChainRules = (atomspace: AtomSpaceEngine): void => {
  // Risk propagation rule
  const riskPropagationPattern: Pattern = {
    id: crypto.randomUUID(),
    atoms: [
      {
        id: 'source',
        type: 'VariableNode',
        name: 'source',
        strength: 1,
        confidence: 1
      },
      {
        id: 'target',
        type: 'VariableNode',
        name: 'target',
        strength: 1,
        confidence: 1
      },
      {
        id: 'link',
        type: 'VariableNode',
        name: 'link',
        strength: 1,
        confidence: 1
      }
    ],
    bindingSet: {
      'source': ['link'],
      'target': ['link']
    }
  };
  
  atomspace.addPattern(riskPropagationPattern);
  
  // Risk propagation rule
  const riskPropagationRule: Rule = {
    id: crypto.randomUUID(),
    name: "Risk Propagation Rule",
    description: "Propagates risk from upstream nodes to downstream nodes",
    pattern: riskPropagationPattern,
    action: (bindings) => {
      const newAtoms: Atom[] = [];
      
      // Get all source nodes that have a connection to target nodes
      const sourceNodes = bindings['source'] || [];
      const targetNodes = bindings['target'] || [];
      const links = bindings['link'] || [];
      
      for (const link of links) {
        if (atomspace.isLink(link)) {
          const typedLink = link as any;
          
          // Only consider active links with high risk
          if (typedLink.active && typedLink.risk > 50) {
            const sourceId = typedLink.outgoingSet[0];
            const targetId = typedLink.outgoingSet[1];
            
            const source = atomspace.getAtom(sourceId);
            const target = atomspace.getAtom(targetId);
            
            if (source && target) {
              // Create a risk propagation link
              newAtoms.push({
                id: `risk-propagation-${sourceId}-${targetId}`,
                type: 'EvaluationLink',
                outgoingSet: ['predicate-high-risk', sourceId, targetId],
                strength: typedLink.risk / 100,
                confidence: 0.75
              } as Link);
              
              // If source is a supplier and target is a manufacturer, 
              // propagate risk to downstream distribution
              if ((source as any).nodeType === 'supplier' && (target as any).nodeType === 'manufacturer') {
                // Find distributors connected to this manufacturer
                const manufacturerLinks = atomspace.getOutgoingLinks(targetId);
                
                for (const mLink of manufacturerLinks) {
                  const distributor = atomspace.getAtom(mLink.outgoingSet[1]);
                  
                  if (distributor && (distributor as any).nodeType === 'distributor') {
                    // Propagate risk with diminished strength
                    newAtoms.push({
                      id: `risk-propagation-${targetId}-${distributor.id}`,
                      type: 'EvaluationLink',
                      outgoingSet: ['predicate-high-risk', targetId, distributor.id],
                      strength: (typedLink.risk * 0.7) / 100, // Diminished risk
                      confidence: 0.6
                    } as Link);
                  }
                }
              }
            }
          }
        }
      }
      
      return newAtoms;
    },
    cost: 0.2
  };
  
  atomspace.addRule(riskPropagationRule);
  
  // Bottleneck identification rule
  const bottleneckPattern: Pattern = {
    id: crypto.randomUUID(),
    atoms: [
      {
        id: 'node',
        type: 'VariableNode',
        name: 'node',
        strength: 1,
        confidence: 1
      }
    ]
  };
  
  atomspace.addPattern(bottleneckPattern);
  
  const bottleneckRule: Rule = {
    id: crypto.randomUUID(),
    name: "Bottleneck Identification Rule",
    description: "Identifies bottlenecks in the supply chain",
    pattern: bottleneckPattern,
    action: (bindings) => {
      const newAtoms: Atom[] = [];
      
      // Get all nodes
      const nodes = bindings['node'] || [];
      
      for (const node of nodes) {
        // Skip end points (suppliers and customers)
        if ((node as any).nodeType === 'supplier' || (node as any).nodeType === 'customer') {
          continue;
        }
        
        // Calculate in-degree and out-degree
        const incomingLinks = atomspace.getIncomingLinks(node.id).filter(link => 
          link.outgoingSet[1] === node.id
        );
        
        const outgoingLinks = atomspace.getOutgoingLinks(node.id);
        
        // Check if this is a potential bottleneck
        if (incomingLinks.length >= 2 && outgoingLinks.length >= 1) {
          // This node receives from multiple sources but outputs to few destinations
          // It's a convergence point (potential bottleneck)
          newAtoms.push({
            id: `bottleneck-${node.id}`,
            type: 'EvaluationLink',
            outgoingSet: ['predicate-bottleneck', node.id],
            strength: 0.8,
            confidence: 0.7
          } as Link);
        }
        
        if (incomingLinks.length === 1 && outgoingLinks.length >= 2) {
          // This node receives from a single source but distributes to many
          // It's a single point of failure
          newAtoms.push({
            id: `bottleneck-${node.id}`,
            type: 'EvaluationLink',
            outgoingSet: ['predicate-bottleneck', node.id],
            strength: 0.9,
            confidence: 0.8
          } as Link);
        }
      }
      
      return newAtoms;
    },
    cost: 0.3
  };
  
  atomspace.addRule(bottleneckRule);
  
  // Redundancy analysis rule
  const redundancyPattern: Pattern = {
    id: crypto.randomUUID(),
    atoms: [
      {
        id: 'manufacturer',
        type: 'VariableNode',
        name: 'manufacturer',
        strength: 1,
        confidence: 1
      },
      {
        id: 'supplier',
        type: 'VariableNode',
        name: 'supplier',
        strength: 1,
        confidence: 1
      }
    ]
  };
  
  atomspace.addPattern(redundancyPattern);
  
  const redundancyRule: Rule = {
    id: crypto.randomUUID(),
    name: "Redundancy Analysis Rule",
    description: "Analyzes supply chain for redundancy and resilience",
    pattern: redundancyPattern,
    action: (bindings) => {
      const newAtoms: Atom[] = [];
      
      // Get manufacturers and suppliers
      const manufacturers = bindings['manufacturer'] || [];
      const suppliers = bindings['supplier'] || [];
      
      // Find manufacturers with single suppliers
      for (const manufacturer of manufacturers) {
        if ((manufacturer as any).nodeType !== 'manufacturer') continue;
        
        // Find links where this manufacturer is the target
        const supplierLinks = atomspace.getIncomingLinks(manufacturer.id).filter(link => {
          const source = atomspace.getAtom(link.outgoingSet[0]);
          return source && (source as any).nodeType === 'supplier';
        });
        
        if (supplierLinks.length === 1) {
          // This manufacturer has only one supplier - no redundancy
          const supplierId = supplierLinks[0].outgoingSet[0];
          
          // Create a redundancy recommendation
          newAtoms.push({
            id: `redundancy-recommendation-${manufacturer.id}`,
            type: 'EvaluationLink',
            name: 'RedundancyRecommendation',
            outgoingSet: ['predicate-bottleneck', manufacturer.id],
            value: {
              recommendation: `Add additional suppliers for ${(manufacturer as any).name}`,
              currentSupplier: supplierId,
              priority: 'high'
            },
            strength: 0.9,
            confidence: 0.8
          } as Link);
        }
      }
      
      // Find critical suppliers (those serving multiple manufacturers)
      for (const supplier of suppliers) {
        if ((supplier as any).nodeType !== 'supplier') continue;
        
        // Find links where this supplier is the source
        const manufacturerLinks = atomspace.getOutgoingLinks(supplier.id).filter(link => {
          const target = atomspace.getAtom(link.outgoingSet[1]);
          return target && (target as any).nodeType === 'manufacturer';
        });
        
        if (manufacturerLinks.length > 1) {
          // This supplier serves multiple manufacturers - it's critical
          newAtoms.push({
            id: `critical-supplier-${supplier.id}`,
            type: 'EvaluationLink',
            name: 'CriticalSupplier',
            outgoingSet: ['predicate-high-risk', supplier.id],
            value: {
              servedManufacturers: manufacturerLinks.map(link => link.outgoingSet[1]),
              criticalityScore: manufacturerLinks.length * 20
            },
            strength: 0.85,
            confidence: 0.8
          } as Link);
        }
      }
      
      return newAtoms;
    },
    cost: 0.25
  };
  
  atomspace.addRule(redundancyRule);
  
  // Add a lead time analysis rule
  const leadTimePattern: Pattern = {
    id: crypto.randomUUID(),
    atoms: [
      {
        id: 'link',
        type: 'VariableNode',
        name: 'link',
        strength: 1,
        confidence: 1
      }
    ]
  };
  
  atomspace.addPattern(leadTimePattern);
  
  const leadTimeRule: Rule = {
    id: crypto.randomUUID(),
    name: "Lead Time Analysis Rule",
    description: "Analyzes lead times across the supply chain",
    pattern: leadTimePattern,
    action: (bindings) => {
      const newAtoms: Atom[] = [];
      const links = bindings['link'] || [];
      
      // Create predicate for lead time assessment
      newAtoms.push({
        id: 'predicate-lead-time',
        type: 'PredicateNode',
        name: 'LeadTimeAssessment',
        strength: 1.0,
        confidence: 1.0
      });
      
      // Analyze lead times
      const allLeadTimes = links.map((link: any) => link.leadTime || 0);
      const avgLeadTime = allLeadTimes.reduce((sum, time) => sum + time, 0) / allLeadTimes.length;
      
      for (const link of links) {
        if ((link as any).leadTime > avgLeadTime * 1.5) {
          // This link has a significantly higher lead time than average
          newAtoms.push({
            id: `lead-time-issue-${link.id}`,
            type: 'EvaluationLink',
            outgoingSet: ['predicate-lead-time', link.id],
            value: {
              assessment: 'High lead time',
              avgLeadTime,
              currentLeadTime: (link as any).leadTime,
              recommendation: 'Consider alternative logistics or closer suppliers'
            },
            strength: 0.85,
            confidence: 0.75
          } as Link);
        }
      }
      
      return newAtoms;
    },
    cost: 0.2
  };
  
  atomspace.addRule(leadTimeRule);
  
  // Add organization and accounting specific rules
  
  // Double-entry accounting validation rule
  const accountingEntryPattern: Pattern = {
    id: crypto.randomUUID(),
    atoms: [
      {
        id: 'transaction',
        type: 'VariableNode',
        name: 'transaction',
        strength: 1,
        confidence: 1
      }
    ]
  };
  
  atomspace.addPattern(accountingEntryPattern);
  
  const doubleEntryRule: Rule = {
    id: crypto.randomUUID(),
    name: "Double-Entry Accounting Rule",
    description: "Validates that debits equal credits for each transaction",
    pattern: accountingEntryPattern,
    action: (bindings) => {
      const newAtoms: Atom[] = [];
      const transactions = bindings['transaction'] || [];
      
      // Create predicate for accounting validation
      newAtoms.push({
        id: 'predicate-accounting-validation',
        type: 'PredicateNode',
        name: 'AccountingValidation',
        strength: 1.0,
        confidence: 1.0
      });
      
      for (const transaction of transactions) {
        if ((transaction as any).nodeType !== 'transaction') continue;
        
        // Find all debit and credit links for this transaction
        const entryLinks = atomspace.getAllLinks().filter(link => 
          link.type === 'EvaluationLink' && 
          link.outgoingSet[0] === transaction.id &&
          ((link as any).relationshipType === 'debit' || (link as any).relationshipType === 'credit')
        ) as AccountingEntryLink[];
        
        // Calculate total debits and credits
        let totalDebits = 0;
        let totalCredits = 0;
        
        for (const entry of entryLinks) {
          if (entry.relationshipType === 'debit') {
            totalDebits += entry.amount;
          } else {
            totalCredits += entry.amount;
          }
        }
        
        // Check if debits equal credits
        const isBalanced = Math.abs(totalDebits - totalCredits) < 0.01;
        
        // Create validation atom
        newAtoms.push({
          id: `accounting-validation-${transaction.id}`,
          type: 'EvaluationLink',
          outgoingSet: ['predicate-accounting-validation', transaction.id],
          value: {
            isBalanced,
            totalDebits,
            totalCredits,
            difference: totalDebits - totalCredits,
            entryCount: entryLinks.length
          },
          strength: isBalanced ? 1.0 : 0.5,
          confidence: 0.95
        } as Link);
        
        // If not balanced, add a warning
        if (!isBalanced) {
          newAtoms.push({
            id: `accounting-warning-${transaction.id}`,
            type: 'EvaluationLink',
            outgoingSet: ['predicate-high-risk', transaction.id],
            value: {
              type: 'unbalanced_transaction',
              severity: 'high',
              message: `Transaction is not balanced: Debits: ${totalDebits}, Credits: ${totalCredits}, Difference: ${totalDebits - totalCredits}`,
            },
            strength: 0.9,
            confidence: 0.95
          } as Link);
        }
      }
      
      return newAtoms;
    },
    cost: 0.15
  };
  
  atomspace.addRule(doubleEntryRule);
  
  // Financial statement validation rule
  const financialStatementPattern: Pattern = {
    id: crypto.randomUUID(),
    atoms: [
      {
        id: 'balanceSheet',
        type: 'VariableNode',
        name: 'balanceSheet',
        strength: 1,
        confidence: 1
      }
    ]
  };
  
  atomspace.addPattern(financialStatementPattern);
  
  const balanceSheetEquationRule: Rule = {
    id: crypto.randomUUID(),
    name: "Balance Sheet Equation Rule",
    description: "Validates that Assets = Liabilities + Equity",
    pattern: financialStatementPattern,
    action: (bindings) => {
      const newAtoms: Atom[] = [];
      const balanceSheets = bindings['balanceSheet'] || [];
      
      for (const bs of balanceSheets) {
        if (!bs.value || !bs.value.totalAssets) continue;
        
        const assets = bs.value.totalAssets;
        const liabilities = bs.value.totalLiabilities;
        const equity = bs.value.totalEquity;
        
        // Check if the equation balances
        const isBalanced = Math.abs(assets - (liabilities + equity)) < 0.01;
        
        if (!isBalanced) {
          newAtoms.push({
            id: `balance-sheet-warning-${bs.id}`,
            type: 'EvaluationLink',
            outgoingSet: ['predicate-high-risk', bs.id],
            value: {
              type: 'unbalanced_balance_sheet',
              severity: 'high',
              message: `Balance sheet equation doesn't balance: Assets: ${assets}, Liabilities + Equity: ${liabilities + equity}, Difference: ${assets - (liabilities + equity)}`,
            },
            strength: 0.9,
            confidence: 0.95
          } as Link);
        }
      }
      
      return newAtoms;
    },
    cost: 0.1
  };
  
  atomspace.addRule(balanceSheetEquationRule);
};

/**
 * Convert regular supply chain data to AtomSpace representation
 */
export const convertToAtomSpaceFormat = (
  nodes: any[],
  links: any[]
): { atoms: Atom[] } => {
  const atoms: Atom[] = [];
  
  // Convert nodes to ConceptNodes
  for (const node of nodes) {
    atoms.push({
      id: node.id,
      type: 'ConceptNode',
      name: node.name,
      value: {
        nodeType: node.type,
        location: node.location,
        capacity: node.capacity,
        reliability: node.reliability
      },
      strength: node.reliability / 100,
      confidence: 0.9
    });
  }
  
  // Convert links to EvaluationLinks
  for (const link of links) {
    atoms.push({
      id: link.id,
      type: 'EvaluationLink',
      value: {
        material: link.material,
        quantity: link.quantity,
        leadTime: link.leadTime,
        cost: link.cost,
        risk: link.risk,
        active: link.active
      },
      outgoingSet: [link.source, link.target],
      strength: (100 - link.risk) / 100,
      confidence: 0.8
    } as Link);
  }
  
  return { atoms };
};

/**
 * Convert AtomSpace representation back to regular supply chain data
 */
export const convertFromAtomSpaceFormat = (
  atoms: Atom[]
): { nodes: any[], links: any[] } => {
  const nodes: any[] = [];
  const links: any[] = [];
  
  for (const atom of atoms) {
    if (atom.type === 'ConceptNode') {
      const node = {
        id: atom.id,
        name: atom.name || '',
        type: atom.value?.nodeType || 'supplier',
        location: atom.value?.location || '',
        capacity: atom.value?.capacity || 0,
        reliability: Math.round(atom.strength * 100)
      };
      nodes.push(node);
    } else if (atom.type === 'EvaluationLink') {
      const link = {
        id: atom.id,
        source: (atom as Link).outgoingSet[0],
        target: (atom as Link).outgoingSet[1],
        material: atom.value?.material || '',
        quantity: atom.value?.quantity || 0,
        leadTime: atom.value?.leadTime || 0,
        cost: atom.value?.cost || 0,
        risk: Math.round((1 - atom.strength) * 100),
        active: atom.value?.active !== false
      };
      links.push(link);
    }
  }
  
  return { nodes, links };
};