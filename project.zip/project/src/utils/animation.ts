import anime from 'animejs';
import { Node, Link } from '../types';

// Animate nodes appearing
export const animateNodesAppear = (nodeElements: SVGElement[]) => {
  anime({
    targets: nodeElements,
    scale: [0, 1],
    opacity: [0, 1],
    delay: anime.stagger(50),
    easing: 'easeOutElastic(1, .5)',
    duration: 800
  });
};

// Animate links appearing
export const animateLinksAppear = (linkElements: SVGElement[]) => {
  anime({
    targets: linkElements,
    strokeDashoffset: [anime.setDashoffset, 0],
    easing: 'easeInOutSine',
    duration: 1200,
    delay: anime.stagger(50),
    direction: 'alternate',
    loop: false
  });
};

// Animate flow along a path (e.g., material flow in supply chain)
export const animateFlow = (
  pathElement: SVGElement, 
  duration: number = 2000, 
  loop: boolean = true
) => {
  // Get the path length first
  const pathLength = (pathElement as SVGPathElement).getTotalLength();
  
  // Check if pathLength is a valid finite number
  if (!Number.isFinite(pathLength) || pathLength <= 0) {
    // Return early if path length is invalid
    return;
  }
  
  // Create a circle element that will travel along the path
  const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
  circle.setAttribute('r', '4');
  circle.setAttribute('fill', '#3b82f6');
  
  // Add circle to the SVG
  const svg = pathElement.closest('svg');
  if (!svg) return;
  
  const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
  group.appendChild(circle);
  svg.appendChild(group);
  
  // Animation using animejs
  const animation = anime({
    targets: circle,
    translateX: (t: number, i: number) => {
      try {
        const calculatedLength = pathLength * t / 100;
        if (!Number.isFinite(calculatedLength)) return 0;
        const point = (pathElement as SVGPathElement).getPointAtLength(calculatedLength);
        return point.x;
      } catch (error) {
        return 0;
      }
    },
    translateY: (t: number, i: number) => {
      try {
        const calculatedLength = pathLength * t / 100;
        if (!Number.isFinite(calculatedLength)) return 0;
        const point = (pathElement as SVGPathElement).getPointAtLength(calculatedLength);
        return point.y;
      } catch (error) {
        return 0;
      }
    },
    easing: 'linear',
    duration: duration,
    loop: loop,
    autoplay: true
  });
  
  return {
    animation,
    cleanup: () => {
      animation.pause();
      if (group.parentNode) {
        group.parentNode.removeChild(group);
      }
    }
  };
};

// Animate a risk event (e.g., disruption in the network)
export const animateRiskEvent = (
  affectedElements: SVGElement[],
  severity: number = 50
) => {
  // Shake effect for severe disruptions
  if (severity > 70) {
    anime({
      targets: affectedElements,
      translateX: [
        { value: -5 * (severity / 100), duration: 100 },
        { value: 5 * (severity / 100), duration: 100 },
        { value: -5 * (severity / 100), duration: 100 },
        { value: 5 * (severity / 100), duration: 100 },
        { value: 0, duration: 100 }
      ],
      translateY: [
        { value: -5 * (severity / 100), duration: 100 },
        { value: 5 * (severity / 100), duration: 100 },
        { value: -5 * (severity / 100), duration: 100 },
        { value: 5 * (severity / 100), duration: 100 },
        { value: 0, duration: 100 }
      ],
      easing: 'easeInOutQuad',
    });
  }
  
  // Color pulse effect
  anime({
    targets: affectedElements,
    fill: ['#ff0000', '#f87171', '#ff0000'],
    stroke: ['#ff0000', '#f87171', '#ff0000'],
    opacity: [1, 0.7, 1],
    scale: [1, 1.1, 1],
    duration: 1000,
    easing: 'easeInOutQuad',
    direction: 'alternate',
    loop: 2
  });
};

// Animate dashboard metrics changes
export const animateMetricChange = (
  element: HTMLElement,
  startValue: number,
  endValue: number,
  suffix: string = '',
  duration: number = 1000
) => {
  // Save the original text color
  const originalColor = window.getComputedStyle(element).color;
  
  // Set the direction of change color
  const isIncrease = endValue > startValue;
  const changeColor = isIncrease ? '#10b981' : '#ef4444';
  
  // Animate the number counting up/down
  const countObj = { count: startValue };
  const animation = anime({
    targets: countObj,
    count: endValue,
    round: 1, // Round to whole number if needed
    duration: duration,
    easing: 'easeInOutQuad',
    update: function() {
      element.innerHTML = `${countObj.count.toFixed(1)}${suffix}`;
    },
    begin: function() {
      anime({
        targets: element,
        color: [originalColor, changeColor],
        duration: duration / 2,
        easing: 'easeOutQuad'
      });
    },
    complete: function() {
      anime({
        targets: element,
        color: [changeColor, originalColor],
        duration: duration / 2,
        easing: 'easeInQuad'
      });
    }
  });
  
  return animation;
};

// Animate optimization process visualization
export const animateOptimization = (
  networkContainer: HTMLElement,
  duration: number = 2000
) => {
  // Create a ripple effect overlay
  const overlay = document.createElement('div');
  overlay.className = 'absolute inset-0 pointer-events-none';
  overlay.style.zIndex = '10';
  networkContainer.appendChild(overlay);
  
  // Create multiple ripples
  for (let i = 0; i < 3; i++) {
    const ripple = document.createElement('div');
    ripple.className = 'absolute left-1/2 top-1/2 rounded-full bg-blue-500 transform -translate-x-1/2 -translate-y-1/2';
    ripple.style.width = '10px';
    ripple.style.height = '10px';
    ripple.style.opacity = '0';
    overlay.appendChild(ripple);
    
    anime({
      targets: ripple,
      scale: [0, 15],
      opacity: [0.6, 0],
      easing: 'easeOutExpo',
      duration: duration,
      delay: i * 300
    });
  }
  
  // Clean up after animation
  setTimeout(() => {
    if (overlay.parentNode) {
      overlay.parentNode.removeChild(overlay);
    }
  }, duration + 1000);
};