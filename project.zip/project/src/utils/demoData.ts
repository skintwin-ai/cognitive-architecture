import { SupplyChainNetwork, Node, Link, RiskEvent } from '../types';

// Utility to generate a random number between min and max
const random = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;

// Suppliers (raw materials)
const suppliers: Node[] = [
  {
    id: 'supplier1',
    type: 'supplier',
    name: 'Raw Materials Co.',
    location: 'Denver, CO',
    capacity: 1000,
    reliability: 85,
  },
  {
    id: 'supplier2',
    type: 'supplier',
    name: 'Primary Resources Inc.',
    location: 'Seattle, WA',
    capacity: 800,
    reliability: 90,
  },
  {
    id: 'supplier3',
    type: 'supplier',
    name: 'Global Materials Ltd.',
    location: 'Austin, TX',
    capacity: 1200,
    reliability: 78,
  },
];

// Manufacturers
const manufacturers: Node[] = [
  {
    id: 'manufacturer1',
    type: 'manufacturer',
    name: 'Assembly Solutions',
    location: 'Detroit, MI',
    capacity: 500,
    reliability: 92,
  },
  {
    id: 'manufacturer2',
    type: 'manufacturer',
    name: 'Production Systems',
    location: 'Phoenix, AZ',
    capacity: 600,
    reliability: 88,
  },
];

// Distributors
const distributors: Node[] = [
  {
    id: 'distributor1',
    type: 'distributor',
    name: 'Regional Logistics',
    location: 'Chicago, IL',
    capacity: 1500,
    reliability: 87,
  },
  {
    id: 'distributor2',
    type: 'distributor',
    name: 'National Distribution',
    location: 'Dallas, TX',
    capacity: 1800,
    reliability: 84,
  },
];

// Retailers
const retailers: Node[] = [
  {
    id: 'retailer1',
    type: 'retailer',
    name: 'MegaStore',
    location: 'New York, NY',
    capacity: 300,
    reliability: 93,
  },
  {
    id: 'retailer2',
    type: 'retailer',
    name: 'ShopMart',
    location: 'Los Angeles, CA',
    capacity: 250,
    reliability: 95,
  },
  {
    id: 'retailer3',
    type: 'retailer',
    name: 'Retail Express',
    location: 'Miami, FL',
    capacity: 200,
    reliability: 91,
  },
];

// Customers
const customers: Node[] = [
  {
    id: 'customer1',
    type: 'customer',
    name: 'Consumers West',
    location: 'San Francisco, CA',
    capacity: 0,
    reliability: 100,
  },
  {
    id: 'customer2',
    type: 'customer',
    name: 'Consumers East',
    location: 'Boston, MA',
    capacity: 0,
    reliability: 100,
  },
];

// Combine all nodes
const nodes: Node[] = [...suppliers, ...manufacturers, ...distributors, ...retailers, ...customers];

// Create links between nodes
const links: Link[] = [
  // Supplier to Manufacturer links
  {
    id: 'link1',
    source: 'supplier1',
    target: 'manufacturer1',
    material: 'Raw Material A',
    quantity: 200,
    leadTime: 5,
    cost: 5000,
    risk: 15,
    active: true,
  },
  {
    id: 'link2',
    source: 'supplier2',
    target: 'manufacturer1',
    material: 'Raw Material B',
    quantity: 150,
    leadTime: 3,
    cost: 4000,
    risk: 10,
    active: true,
  },
  {
    id: 'link3',
    source: 'supplier3',
    target: 'manufacturer2',
    material: 'Raw Material C',
    quantity: 180,
    leadTime: 7,
    cost: 6000,
    risk: 20,
    active: true,
  },
  {
    id: 'link4',
    source: 'supplier1',
    target: 'manufacturer2',
    material: 'Raw Material A',
    quantity: 120,
    leadTime: 5,
    cost: 3000,
    risk: 12,
    active: true,
  },

  // Manufacturer to Distributor links
  {
    id: 'link5',
    source: 'manufacturer1',
    target: 'distributor1',
    material: 'Product X',
    quantity: 100,
    leadTime: 4,
    cost: 8000,
    risk: 18,
    active: true,
  },
  {
    id: 'link6',
    source: 'manufacturer1',
    target: 'distributor2',
    material: 'Product Y',
    quantity: 80,
    leadTime: 6,
    cost: 7000,
    risk: 22,
    active: true,
  },
  {
    id: 'link7',
    source: 'manufacturer2',
    target: 'distributor1',
    material: 'Product Z',
    quantity: 90,
    leadTime: 5,
    cost: 7500,
    risk: 20,
    active: true,
  },
  {
    id: 'link8',
    source: 'manufacturer2',
    target: 'distributor2',
    material: 'Product W',
    quantity: 110,
    leadTime: 3,
    cost: 9000,
    risk: 15,
    active: true,
  },

  // Distributor to Retailer links
  {
    id: 'link9',
    source: 'distributor1',
    target: 'retailer1',
    material: 'Finished Product X',
    quantity: 50,
    leadTime: 2,
    cost: 4000,
    risk: 10,
    active: true,
  },
  {
    id: 'link10',
    source: 'distributor1',
    target: 'retailer2',
    material: 'Finished Product Y',
    quantity: 40,
    leadTime: 3,
    cost: 3500,
    risk: 12,
    active: true,
  },
  {
    id: 'link11',
    source: 'distributor2',
    target: 'retailer3',
    material: 'Finished Product Z',
    quantity: 45,
    leadTime: 4,
    cost: 3800,
    risk: 15,
    active: true,
  },
  {
    id: 'link12',
    source: 'distributor2',
    target: 'retailer1',
    material: 'Finished Product W',
    quantity: 55,
    leadTime: 2,
    cost: 4200,
    risk: 8,
    active: true,
  },

  // Retailer to Customer links
  {
    id: 'link13',
    source: 'retailer1',
    target: 'customer1',
    material: 'Consumer Product A',
    quantity: 30,
    leadTime: 1,
    cost: 2000,
    risk: 5,
    active: true,
  },
  {
    id: 'link14',
    source: 'retailer2',
    target: 'customer1',
    material: 'Consumer Product B',
    quantity: 25,
    leadTime: 1,
    cost: 1800,
    risk: 4,
    active: true,
  },
  {
    id: 'link15',
    source: 'retailer3',
    target: 'customer2',
    material: 'Consumer Product C',
    quantity: 35,
    leadTime: 2,
    cost: 2200,
    risk: 6,
    active: true,
  },
  {
    id: 'link16',
    source: 'retailer1',
    target: 'customer2',
    material: 'Consumer Product D',
    quantity: 20,
    leadTime: 1,
    cost: 1500,
    risk: 3,
    active: true,
  },
];

// Sample risk events
const risks: RiskEvent[] = [
  {
    id: 'risk1',
    name: 'Natural Disaster',
    affectedNodeIds: ['supplier1', 'supplier2'],
    affectedLinkIds: ['link1', 'link2'],
    severity: 80,
    probability: 15,
    description: 'Potential flooding at supplier locations affecting raw material availability',
  },
  {
    id: 'risk2',
    name: 'Transportation Strike',
    affectedNodeIds: [],
    affectedLinkIds: ['link5', 'link6', 'link7', 'link8'],
    severity: 60,
    probability: 25,
    description: 'Labor dispute causing delays in product distribution channels',
  },
  {
    id: 'risk3',
    name: 'Production Failure',
    affectedNodeIds: ['manufacturer2'],
    affectedLinkIds: [],
    severity: 70,
    probability: 20,
    description: 'Equipment malfunction potentially halting production',
  },
  {
    id: 'risk4',
    name: 'Demand Spike',
    affectedNodeIds: ['retailer1', 'retailer2', 'retailer3'],
    affectedLinkIds: ['link13', 'link14', 'link15', 'link16'],
    severity: 40,
    probability: 35,
    description: 'Unexpected increase in customer demand straining inventory',
  },
];

export const demoNetwork: SupplyChainNetwork = {
  nodes,
  links,
  risks,
  state: {
    healthScore: 82,
    resilience: 75,
    efficiency: 80,
    totalCost: 75000,
    riskScore: 18,
  },
  settings: {
    riskProbability: 25,
    demandVolatility: 30,
    optimizeFor: 'balanced',
    visualizationMode: 'force-directed',
    animationSpeed: 50,
    showLabels: true,
    highContrastMode: false,
  },
};

export default demoNetwork;