import { 
  AtomSpaceEngine, 
  createSupplyChainAtomSpace, 
  initializeSupplyChainRules 
} from './atomspaceEngine';
import {
  OrgNode,
  AccountNode,
  TransactionNode,
  TrialBalanceNode,
  OrgRelationshipLink
} from '../types/atomspace';

/**
 * OrgSpace Engine - Extends AtomSpace with organization-specific functionality
 * Specializes in accounting and organizational structure modeling
 */
export class OrgSpaceEngine extends AtomSpaceEngine {
  constructor(name: string = 'Organization Knowledge Graph', description?: string) {
    super(name, description);
    this.initializeOrgSpacePredicates();
  }
  
  /**
   * Initialize basic predicates and categories for OrgSpace
   */
  private initializeOrgSpacePredicates(): void {
    // Create basic accounting predicates
    const predicates = [
      {
        id: 'predicate-balanced',
        name: 'Balanced',
        description: 'Indicates that an accounting entity is balanced'
      },
      {
        id: 'predicate-unbalanced',
        name: 'Unbalanced',
        description: 'Indicates that an accounting entity is unbalanced'
      },
      {
        id: 'predicate-audit-required',
        name: 'AuditRequired',
        description: 'Indicates that an accounting entity requires audit attention'
      },
      {
        id: 'predicate-tax-relevant',
        name: 'TaxRelevant',
        description: 'Indicates that an entity has tax implications'
      },
      {
        id: 'predicate-reconciled',
        name: 'Reconciled',
        description: 'Indicates that an accounting entity has been reconciled'
      }
    ];
    
    // Create account type categories
    const accountTypes = [
      {
        id: 'category-asset',
        name: 'Asset Accounts',
        description: 'Accounts representing economic resources owned by an entity'
      },
      {
        id: 'category-liability',
        name: 'Liability Accounts',
        description: 'Accounts representing obligations of an entity'
      },
      {
        id: 'category-equity',
        name: 'Equity Accounts',
        description: 'Accounts representing ownership interest in assets'
      },
      {
        id: 'category-revenue',
        name: 'Revenue Accounts',
        description: 'Accounts representing increases in equity from business activities'
      },
      {
        id: 'category-expense',
        name: 'Expense Accounts',
        description: 'Accounts representing decreases in equity from business activities'
      }
    ];
    
    // Add predicates to atomspace
    for (const pred of predicates) {
      this.addAtom({
        id: pred.id,
        type: 'PredicateNode',
        name: pred.name,
        value: {
          description: pred.description
        },
        strength: 1.0,
        confidence: 1.0
      });
    }
    
    // Add account type categories
    for (const cat of accountTypes) {
      this.addAtom({
        id: cat.id,
        type: 'ConceptNode',
        name: cat.name,
        value: {
          description: cat.description
        },
        strength: 1.0,
        confidence: 1.0
      });
    }
  }
  
  /**
   * Create a standard chart of accounts for a new organization
   */
  createStandardChartOfAccounts(orgId: string, includeDetailedAccounts: boolean = false): AccountNode[] {
    // Create basic account structure
    const basicAccounts = [
      // Asset accounts
      {
        id: `account-${orgId}-1000`,
        accountNumber: '1000',
        accountName: 'Assets',
        accountType: 'asset' as const,
        isDebit: true,
        balance: 0
      },
      {
        id: `account-${orgId}-1100`,
        accountNumber: '1100',
        accountName: 'Current Assets',
        accountType: 'asset' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-1000`,
        balance: 0
      },
      {
        id: `account-${orgId}-1110`,
        accountNumber: '1110',
        accountName: 'Cash',
        accountType: 'asset' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-1100`,
        balance: 0
      },
      {
        id: `account-${orgId}-1200`,
        accountNumber: '1200',
        accountName: 'Accounts Receivable',
        accountType: 'asset' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-1100`,
        balance: 0
      },
      
      // Liability accounts
      {
        id: `account-${orgId}-2000`,
        accountNumber: '2000',
        accountName: 'Liabilities',
        accountType: 'liability' as const,
        isDebit: false,
        balance: 0
      },
      {
        id: `account-${orgId}-2100`,
        accountNumber: '2100',
        accountName: 'Current Liabilities',
        accountType: 'liability' as const,
        isDebit: false,
        parentAccount: `account-${orgId}-2000`,
        balance: 0
      },
      {
        id: `account-${orgId}-2110`,
        accountNumber: '2110',
        accountName: 'Accounts Payable',
        accountType: 'liability' as const,
        isDebit: false,
        parentAccount: `account-${orgId}-2100`,
        balance: 0
      },
      
      // Equity accounts
      {
        id: `account-${orgId}-3000`,
        accountNumber: '3000',
        accountName: 'Equity',
        accountType: 'equity' as const,
        isDebit: false,
        balance: 0
      },
      {
        id: `account-${orgId}-3100`,
        accountNumber: '3100',
        accountName: 'Common Stock',
        accountType: 'equity' as const,
        isDebit: false,
        parentAccount: `account-${orgId}-3000`,
        balance: 0
      },
      {
        id: `account-${orgId}-3900`,
        accountNumber: '3900',
        accountName: 'Retained Earnings',
        accountType: 'equity' as const,
        isDebit: false,
        parentAccount: `account-${orgId}-3000`,
        balance: 0
      },
      
      // Revenue accounts
      {
        id: `account-${orgId}-4000`,
        accountNumber: '4000',
        accountName: 'Revenue',
        accountType: 'revenue' as const,
        isDebit: false,
        balance: 0
      },
      {
        id: `account-${orgId}-4100`,
        accountNumber: '4100',
        accountName: 'Sales Revenue',
        accountType: 'revenue' as const,
        isDebit: false,
        parentAccount: `account-${orgId}-4000`,
        balance: 0
      },
      
      // Expense accounts
      {
        id: `account-${orgId}-5000`,
        accountNumber: '5000',
        accountName: 'Expenses',
        accountType: 'expense' as const,
        isDebit: true,
        balance: 0
      },
      {
        id: `account-${orgId}-5100`,
        accountNumber: '5100',
        accountName: 'Cost of Goods Sold',
        accountType: 'expense' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-5000`,
        balance: 0
      }
    ];
    
    // Add detailed accounts if requested
    const detailedAccounts = includeDetailedAccounts ? [
      // More asset accounts
      {
        id: `account-${orgId}-1120`,
        accountNumber: '1120',
        accountName: 'Inventory',
        accountType: 'asset' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-1100`,
        balance: 0
      },
      {
        id: `account-${orgId}-1130`,
        accountNumber: '1130',
        accountName: 'Prepaid Expenses',
        accountType: 'asset' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-1100`,
        balance: 0
      },
      {
        id: `account-${orgId}-1300`,
        accountNumber: '1300',
        accountName: 'Fixed Assets',
        accountType: 'asset' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-1000`,
        balance: 0
      },
      {
        id: `account-${orgId}-1310`,
        accountNumber: '1310',
        accountName: 'Equipment',
        accountType: 'asset' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-1300`,
        balance: 0
      },
      {
        id: `account-${orgId}-1320`,
        accountNumber: '1320',
        accountName: 'Buildings',
        accountType: 'asset' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-1300`,
        balance: 0
      },
      {
        id: `account-${orgId}-1330`,
        accountNumber: '1330',
        accountName: 'Accumulated Depreciation',
        accountType: 'asset' as const,
        isDebit: false, // Contra-asset, so credit balance
        parentAccount: `account-${orgId}-1300`,
        balance: 0
      },
      
      // More liability accounts
      {
        id: `account-${orgId}-2120`,
        accountNumber: '2120',
        accountName: 'Wages Payable',
        accountType: 'liability' as const,
        isDebit: false,
        parentAccount: `account-${orgId}-2100`,
        balance: 0
      },
      {
        id: `account-${orgId}-2130`,
        accountNumber: '2130',
        accountName: 'Taxes Payable',
        accountType: 'liability' as const,
        isDebit: false,
        parentAccount: `account-${orgId}-2100`,
        balance: 0
      },
      {
        id: `account-${orgId}-2200`,
        accountNumber: '2200',
        accountName: 'Long-term Liabilities',
        accountType: 'liability' as const,
        isDebit: false,
        parentAccount: `account-${orgId}-2000`,
        balance: 0
      },
      {
        id: `account-${orgId}-2210`,
        accountNumber: '2210',
        accountName: 'Long-term Loans',
        accountType: 'liability' as const,
        isDebit: false,
        parentAccount: `account-${orgId}-2200`,
        balance: 0
      },
      
      // More revenue accounts
      {
        id: `account-${orgId}-4200`,
        accountNumber: '4200',
        accountName: 'Service Revenue',
        accountType: 'revenue' as const,
        isDebit: false,
        parentAccount: `account-${orgId}-4000`,
        balance: 0
      },
      {
        id: `account-${orgId}-4300`,
        accountNumber: '4300',
        accountName: 'Interest Income',
        accountType: 'revenue' as const,
        isDebit: false,
        parentAccount: `account-${orgId}-4000`,
        balance: 0
      },
      
      // More expense accounts
      {
        id: `account-${orgId}-5200`,
        accountNumber: '5200',
        accountName: 'Salary Expense',
        accountType: 'expense' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-5000`,
        balance: 0
      },
      {
        id: `account-${orgId}-5300`,
        accountNumber: '5300',
        accountName: 'Rent Expense',
        accountType: 'expense' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-5000`,
        balance: 0
      },
      {
        id: `account-${orgId}-5400`,
        accountNumber: '5400',
        accountName: 'Utilities Expense',
        accountType: 'expense' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-5000`,
        balance: 0
      },
      {
        id: `account-${orgId}-5500`,
        accountNumber: '5500',
        accountName: 'Depreciation Expense',
        accountType: 'expense' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-5000`,
        balance: 0
      },
      {
        id: `account-${orgId}-5600`,
        accountNumber: '5600',
        accountName: 'Interest Expense',
        accountType: 'expense' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-5000`,
        balance: 0
      },
      {
        id: `account-${orgId}-5700`,
        accountNumber: '5700',
        accountName: 'Tax Expense',
        accountType: 'expense' as const,
        isDebit: true,
        parentAccount: `account-${orgId}-5000`,
        balance: 0
      }
    ] : [];
    
    // Combine accounts and create them in the atomspace
    const allAccounts = [...basicAccounts, ...detailedAccounts];
    return this.createChartOfAccounts(orgId, allAccounts);
  }
  
  /**
   * Initialize accounting rules for an organization
   */
  initializeAccountingRules(): void {
    // Initialize double-entry accounting validation rule
    const transactionValidationPattern = {
      id: crypto.randomUUID(),
      atoms: [
        {
          id: 'transaction',
          type: 'VariableNode',
          name: 'transaction',
          strength: 1,
          confidence: 1
        }
      ]
    };
    
    this.addPattern(transactionValidationPattern);
    
    const transactionValidationRule = {
      id: crypto.randomUUID(),
      name: "Transaction Validation Rule",
      description: "Validates that accounting entries follow double-entry principles",
      pattern: transactionValidationPattern,
      action: (bindings: Record<string, any[]>) => {
        const newAtoms: any[] = [];
        const transactions = bindings['transaction'] || [];
        
        for (const transaction of transactions) {
          if (transaction.nodeType !== 'transaction') continue;
          
          // Find all entries for this transaction
          const entryLinks = this.getIncomingLinks(transaction.id).filter(link => 
            link.type === 'EvaluationLink' && 
            (link.relationshipType === 'debit' || link.relationshipType === 'credit')
          );
          
          // Calculate totals
          let totalDebits = 0;
          let totalCredits = 0;
          
          for (const entry of entryLinks) {
            if (entry.relationshipType === 'debit') {
              totalDebits += entry.amount || 0;
            } else {
              totalCredits += entry.amount || 0;
            }
          }
          
          // Check if balanced
          const isBalanced = Math.abs(totalDebits - totalCredits) < 0.01;
          
          // Add validation result
          newAtoms.push({
            id: `validation-${transaction.id}`,
            type: 'EvaluationLink',
            outgoingSet: [isBalanced ? 'predicate-balanced' : 'predicate-unbalanced', transaction.id],
            value: {
              totalDebits,
              totalCredits,
              difference: totalDebits - totalCredits,
              entryCount: entryLinks.length
            },
            strength: isBalanced ? 1.0 : 0.5,
            confidence: 0.95
          });
        }
        
        return newAtoms;
      },
      cost: 0.1
    };
    
    this.addRule(transactionValidationRule);
    
    // Add financial statement validation rule
    const financialStatementPattern = {
      id: crypto.randomUUID(),
      atoms: [
        {
          id: 'trialBalance',
          type: 'VariableNode',
          name: 'trialBalance',
          strength: 1,
          confidence: 1
        }
      ]
    };
    
    this.addPattern(financialStatementPattern);
    
    const financialStatementRule = {
      id: crypto.randomUUID(),
      name: "Financial Statement Validation Rule",
      description: "Validates trial balance and derived financial statements",
      pattern: financialStatementPattern,
      action: (bindings: Record<string, any[]>) => {
        const newAtoms: any[] = [];
        const trialBalances = bindings['trialBalance'] || [];
        
        for (const tb of trialBalances) {
          if (tb.nodeType !== 'trialBalance') continue;
          
          // Check if trial balance is balanced
          const isBalanced = Math.abs(tb.totalDebits - tb.totalCredits) < 0.01;
          
          // Add validation result
          newAtoms.push({
            id: `validation-${tb.id}`,
            type: 'EvaluationLink',
            outgoingSet: [isBalanced ? 'predicate-balanced' : 'predicate-unbalanced', tb.id],
            value: {
              totalDebits: tb.totalDebits,
              totalCredits: tb.totalCredits,
              difference: tb.totalDebits - tb.totalCredits,
              status: tb.status
            },
            strength: isBalanced ? 1.0 : 0.5,
            confidence: 0.95
          });
          
          // If not balanced, mark for audit
          if (!isBalanced) {
            newAtoms.push({
              id: `audit-required-${tb.id}`,
              type: 'EvaluationLink',
              outgoingSet: ['predicate-audit-required', tb.id],
              value: {
                reason: 'Unbalanced trial balance',
                difference: tb.totalDebits - tb.totalCredits
              },
              strength: 0.9,
              confidence: 0.9
            });
          }
        }
        
        return newAtoms;
      },
      cost: 0.2
    };
    
    this.addRule(financialStatementRule);
  }
  
  /**
   * Import organization data into the atomspace
   */
  importOrganizationData(orgData: any, accounts: any[], transactions: any[]): void {
    // Create organization node
    const org = this.createOrganization({
      id: orgData.id,
      orgName: orgData.name,
      legalStructure: orgData.legalStructure,
      fiscalYear: orgData.fiscalYear,
      industry: orgData.industry,
      dateEstablished: orgData.dateEstablished,
      metadata: orgData.metadata
    });
    
    // Create chart of accounts
    this.createChartOfAccounts(org.id, accounts);
    
    // Create transactions
    for (const txnData of transactions) {
      this.recordTransaction(
        org.id, 
        {
          id: txnData.id,
          description: txnData.description,
          transactionDate: txnData.date,
          status: txnData.status || 'posted',
          reference: txnData.reference,
          metadata: txnData.metadata
        },
        txnData.entries
      );
    }
    
    // Generate trial balance
    const today = new Date().toISOString().split('T')[0];
    this.createTrialBalance(org.id, today);
  }
  
  /**
   * Analyze financial health of an organization
   */
  analyzeFinancialHealth(orgId: string): {
    liquidityRatio: number,
    debtToEquityRatio: number,
    profitMargin: number,
    returnOnAssets: number,
    healthScore: number
  } {
    // Get the organization
    const org = this.getAtom(orgId);
    if (!org) {
      throw new Error('Organization not found');
    }
    
    // Find the chart of accounts
    const coaLink = this.getAllLinks().find(link => 
      link.type === 'EvaluationLink' && 
      link.outgoingSet[0] === orgId &&
      link.outgoingSet[1].startsWith('chart-of-accounts-')
    );
    
    if (!coaLink) {
      throw new Error('Chart of accounts not found');
    }
    
    const chartOfAccountsId = coaLink.outgoingSet[1];
    
    // Get all accounts in the chart
    const accountLinks = this.getAllLinks().filter(link => 
      link.type === 'MemberLink' && 
      link.outgoingSet[0] === chartOfAccountsId
    );
    
    const accountIds = accountLinks.map(link => link.outgoingSet[1]);
    const accounts = accountIds.map(id => this.getAtom(id) as AccountNode).filter(Boolean);
    
    // Calculate financial ratios
    
    // Current assets and liabilities
    const currentAssets = accounts.filter(account => 
      account.accountType === 'asset' && account.accountNumber.startsWith('11')
    ).reduce((sum, account) => sum + account.balance, 0);
    
    const currentLiabilities = accounts.filter(account => 
      account.accountType === 'liability' && account.accountNumber.startsWith('21')
    ).reduce((sum, account) => sum + account.balance, 0);
    
    // Total assets, liabilities, and equity
    const totalAssets = accounts.filter(account => 
      account.accountType === 'asset'
    ).reduce((sum, account) => sum + account.balance, 0);
    
    const totalLiabilities = accounts.filter(account => 
      account.accountType === 'liability'
    ).reduce((sum, account) => sum + account.balance, 0);
    
    const totalEquity = accounts.filter(account => 
      account.accountType === 'equity'
    ).reduce((sum, account) => sum + account.balance, 0);
    
    // Revenue and expenses
    const totalRevenue = accounts.filter(account => 
      account.accountType === 'revenue'
    ).reduce((sum, account) => sum + account.balance, 0);
    
    const totalExpenses = accounts.filter(account => 
      account.accountType === 'expense'
    ).reduce((sum, account) => sum + account.balance, 0);
    
    const netIncome = totalRevenue - totalExpenses;
    
    // Calculate ratios
    const liquidityRatio = currentLiabilities > 0 ? currentAssets / currentLiabilities : 0;
    const debtToEquityRatio = totalEquity > 0 ? totalLiabilities / totalEquity : 0;
    const profitMargin = totalRevenue > 0 ? (netIncome / totalRevenue) * 100 : 0;
    const returnOnAssets = totalAssets > 0 ? (netIncome / totalAssets) * 100 : 0;
    
    // Calculate overall health score (0-100)
    // This is a simplified scoring system - a real implementation would be more sophisticated
    
    let healthScore = 50; // Start at neutral
    
    // Liquidity: 0-25 points
    if (liquidityRatio >= 2) healthScore += 25;
    else if (liquidityRatio >= 1.5) healthScore += 20;
    else if (liquidityRatio >= 1) healthScore += 15;
    else if (liquidityRatio >= 0.5) healthScore += 10;
    else healthScore += 5;
    
    // Debt to Equity: 0-25 points
    if (debtToEquityRatio <= 0.5) healthScore += 25;
    else if (debtToEquityRatio <= 1) healthScore += 20;
    else if (debtToEquityRatio <= 1.5) healthScore += 15;
    else if (debtToEquityRatio <= 2) healthScore += 10;
    else healthScore += 5;
    
    // Profitability: 0-25 points
    if (profitMargin >= 20) healthScore += 25;
    else if (profitMargin >= 15) healthScore += 20;
    else if (profitMargin >= 10) healthScore += 15;
    else if (profitMargin >= 5) healthScore += 10;
    else if (profitMargin >= 0) healthScore += 5;
    
    // ROA: 0-25 points
    if (returnOnAssets >= 15) healthScore += 25;
    else if (returnOnAssets >= 10) healthScore += 20;
    else if (returnOnAssets >= 5) healthScore += 15;
    else if (returnOnAssets >= 2) healthScore += 10;
    else if (returnOnAssets >= 0) healthScore += 5;
    
    // Normalize to 0-100 scale
    healthScore = Math.min(100, Math.max(0, healthScore));
    
    return {
      liquidityRatio,
      debtToEquityRatio,
      profitMargin,
      returnOnAssets,
      healthScore
    };
  }
}

/**
 * Create a new OrgSpace instance
 */
export const createOrgSpace = (
  organizationName: string,
  legalStructure: 'sole_proprietorship' | 'partnership' | 'corporation' | 'llc' | 'nonprofit' | 'other' = 'corporation',
  includeStandardAccounts: boolean = true
): { 
  orgSpaceEngine: OrgSpaceEngine, 
  organization: OrgNode, 
  accounts: AccountNode[] 
} => {
  // Create the OrgSpace engine
  const orgSpaceEngine = new OrgSpaceEngine(`${organizationName} Knowledge Graph`);
  
  // Initialize accounting rules
  orgSpaceEngine.initializeAccountingRules();
  
  // Create organization
  const organization = orgSpaceEngine.createOrganization({
    orgName: organizationName,
    legalStructure: legalStructure,
    fiscalYear: {
      startMonth: 1,
      startDay: 1
    }
  });
  
  // Create standard chart of accounts if requested
  let accounts: AccountNode[] = [];
  
  if (includeStandardAccounts) {
    accounts = orgSpaceEngine.createStandardChartOfAccounts(organization.id, true);
  }
  
  return { 
    orgSpaceEngine, 
    organization, 
    accounts 
  };
};

/**
 * Create sample transactions for testing
 */
export const createSampleTransactions = (
  orgSpaceEngine: OrgSpaceEngine, 
  orgId: string, 
  accounts: AccountNode[]
): void => {
  // Find specific accounts
  const getAccount = (acctNumber: string): AccountNode | undefined => 
    accounts.find(acct => acct.accountNumber === acctNumber);
  
  const cashAcct = getAccount('1110');
  const accountsReceivable = getAccount('1200');
  const salesRevenue = getAccount('4100');
  const cogsAcct = getAccount('5100');
  const inventoryAcct = getAccount('1120');
  const accountsPayable = getAccount('2110');
  
  if (!cashAcct || !accountsReceivable || !salesRevenue || !cogsAcct || !inventoryAcct || !accountsPayable) {
    throw new Error('Required accounts not found');
  }
  
  // Sample transactions
  
  // Transaction 1: Initial investment
  orgSpaceEngine.recordTransaction(
    orgId,
    {
      description: 'Initial capital investment',
      transactionDate: '2025-01-01',
      status: 'posted'
    },
    [
      { accountId: cashAcct.id, isDebit: true, amount: 100000 },
      { accountId: getAccount('3100')!.id, isDebit: false, amount: 100000 }
    ]
  );
  
  // Transaction 2: Purchase inventory
  orgSpaceEngine.recordTransaction(
    orgId,
    {
      description: 'Purchase inventory on credit',
      transactionDate: '2025-01-15',
      status: 'posted'
    },
    [
      { accountId: inventoryAcct.id, isDebit: true, amount: 25000 },
      { accountId: accountsPayable.id, isDebit: false, amount: 25000 }
    ]
  );
  
  // Transaction 3: Pay for inventory
  orgSpaceEngine.recordTransaction(
    orgId,
    {
      description: 'Pay for inventory purchased on credit',
      transactionDate: '2025-02-01',
      status: 'posted'
    },
    [
      { accountId: accountsPayable.id, isDebit: true, amount: 25000 },
      { accountId: cashAcct.id, isDebit: false, amount: 25000 }
    ]
  );
  
  // Transaction 4: Sales on credit
  orgSpaceEngine.recordTransaction(
    orgId,
    {
      description: 'Sales on credit',
      transactionDate: '2025-02-15',
      status: 'posted'
    },
    [
      { accountId: accountsReceivable.id, isDebit: true, amount: 40000 },
      { accountId: salesRevenue.id, isDebit: false, amount: 40000 }
    ]
  );
  
  // Transaction 5: Cost of goods sold for the sales
  orgSpaceEngine.recordTransaction(
    orgId,
    {
      description: 'Cost of goods sold for credit sales',
      transactionDate: '2025-02-15',
      status: 'posted'
    },
    [
      { accountId: cogsAcct.id, isDebit: true, amount: 20000 },
      { accountId: inventoryAcct.id, isDebit: false, amount: 20000 }
    ]
  );
  
  // Transaction 6: Receive payment for credit sales
  orgSpaceEngine.recordTransaction(
    orgId,
    {
      description: 'Receive payment for credit sales',
      transactionDate: '2025-03-01',
      status: 'posted'
    },
    [
      { accountId: cashAcct.id, isDebit: true, amount: 40000 },
      { accountId: accountsReceivable.id, isDebit: false, amount: 40000 }
    ]
  );
  
  // Transaction 7: Pay rent
  const rentExpense = getAccount('5300');
  if (rentExpense) {
    orgSpaceEngine.recordTransaction(
      orgId,
      {
        description: 'Pay rent expense',
        transactionDate: '2025-03-10',
        status: 'posted'
      },
      [
        { accountId: rentExpense.id, isDebit: true, amount: 5000 },
        { accountId: cashAcct.id, isDebit: false, amount: 5000 }
      ]
    );
  }
  
  // Transaction 8: Pay utilities
  const utilitiesExpense = getAccount('5400');
  if (utilitiesExpense) {
    orgSpaceEngine.recordTransaction(
      orgId,
      {
        description: 'Pay utilities expense',
        transactionDate: '2025-03-15',
        status: 'posted'
      },
      [
        { accountId: utilitiesExpense.id, isDebit: true, amount: 2000 },
        { accountId: cashAcct.id, isDebit: false, amount: 2000 }
      ]
    );
  }
  
  // Transaction 9: Pay salaries
  const salaryExpense = getAccount('5200');
  if (salaryExpense) {
    orgSpaceEngine.recordTransaction(
      orgId,
      {
        description: 'Pay employee salaries',
        transactionDate: '2025-03-31',
        status: 'posted'
      },
      [
        { accountId: salaryExpense.id, isDebit: true, amount: 15000 },
        { accountId: cashAcct.id, isDebit: false, amount: 15000 }
      ]
    );
  }
  
  // Generate trial balance
  orgSpaceEngine.createTrialBalance(orgId, '2025-03-31');
};