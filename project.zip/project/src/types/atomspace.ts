/**
 * AtomSpace Framework Types
 * 
 * These types implement the foundational concepts of the AtomSpace framework
 * for knowledge representation in hypergraphs.
 */

// Basic Atom Types
export interface Atom {
  id: string;
  type: string;
  name?: string;
  value?: any;
  strength: number; // Truth value strength (0-1)
  confidence: number; // Truth value confidence (0-1)
}

export interface Node extends Atom {
  type: 'ConceptNode' | 'PredicateNode' | 'VariableNode';
}

export interface Link extends Atom {
  type: 'EvaluationLink' | 'InheritanceLink' | 'MemberLink' | 'AndLink' | 'OrLink' | 'NotLink';
  outgoingSet: string[]; // Array of atom IDs this link connects
}

// AtomSpace - the primary container for atoms
export interface AtomSpace {
  id: string;
  name: string;
  description?: string;
  atoms: Record<string, Atom>; // Map of atom IDs to atoms
}

// Pattern types for querying and matching
export interface Pattern {
  id: string;
  atoms: Atom[];
  bindingSet?: Record<string, string[]>; // Variable name to atom IDs mapping for constraints
}

// Inference types
export interface Rule {
  id: string;
  name: string;
  description?: string;
  pattern: Pattern; // Pattern to match
  action: (bindings: Record<string, Atom[]>) => Atom[]; // Action to perform
  cost: number; // Computational cost (0-1)
}

// Attention allocation
export interface AttentionalFocus {
  atoms: string[]; // IDs of atoms in focus
  shortTermImportance: Record<string, number>; // STI values for atoms
  longTermImportance: Record<string, number>; // LTI values for atoms
}

// Supply chain specific atomspace extensions
export interface SupplyChainAtomSpace extends AtomSpace {
  nodes: Record<string, SupplyChainNode>;
  links: Record<string, SupplyChainLink>;
  patterns: Record<string, Pattern>;
  rules: Record<string, Rule>;
  attention: AttentionalFocus;
}

export interface SupplyChainNode extends Node {
  type: 'ConceptNode';
  nodeType: 'supplier' | 'manufacturer' | 'distributor' | 'retailer' | 'customer';
  location: string;
  capacity: number;
  reliability: number;
  coordinates?: { x: number; y: number };
}

export interface SupplyChainLink extends Link {
  type: 'EvaluationLink';
  relationshipType: 'supplies' | 'produces' | 'distributes' | 'sells';
  material: string;
  quantity: number;
  leadTime: number;
  cost: number;
  risk: number;
  active: boolean;
}

// Organization specific AtomSpace extensions
export interface OrgAtomSpace extends AtomSpace {
  organizations: Record<string, OrgNode>;
  accounts: Record<string, AccountNode>;
  transactions: Record<string, TransactionNode>;
  relationships: Record<string, OrgRelationshipLink>;
  patterns: Record<string, Pattern>;
  rules: Record<string, Rule>;
  attention: AttentionalFocus;
}

export interface OrgNode extends Node {
  type: 'ConceptNode';
  nodeType: 'organization';
  orgName: string;
  taxId?: string;
  legalStructure: 'sole_proprietorship' | 'partnership' | 'corporation' | 'llc' | 'nonprofit' | 'other';
  fiscalYear: {
    startMonth: number;
    startDay: number;
  };
  metadata?: Record<string, any>;
  industry?: string;
  dateEstablished?: string;
}

export interface AccountNode extends Node {
  type: 'ConceptNode';
  nodeType: 'account';
  accountNumber: string;
  accountName: string;
  accountType: 'asset' | 'liability' | 'equity' | 'revenue' | 'expense';
  subType?: string;
  balance: number;
  currency: string;
  isDebit: boolean;
  parentAccount?: string; // ID of parent account
  metadata?: Record<string, any>;
  tags?: string[];
}

export interface TransactionNode extends Node {
  type: 'ConceptNode';
  nodeType: 'transaction';
  transactionDate: string;
  postingDate?: string;
  description: string;
  amount: number;
  currency: string;
  status: 'pending' | 'posted' | 'reconciled' | 'voided';
  reference?: string;
  metadata?: Record<string, any>;
}

export interface TrialBalanceNode extends Node {
  type: 'ConceptNode';
  nodeType: 'trialBalance';
  asOfDate: string;
  status: 'draft' | 'final' | 'adjusted';
  totalDebits: number;
  totalCredits: number;
  isBalanced: boolean;
  currency: string;
  metadata?: Record<string, any>;
}

export interface OrgRelationshipLink extends Link {
  type: 'EvaluationLink';
  relationshipType: 'owns' | 'contains' | 'employs' | 'transactsWith' | 'debit' | 'credit' | 'includes';
}

export interface AccountingEntryLink extends Link {
  type: 'EvaluationLink';
  relationshipType: 'debit' | 'credit';
  amount: number;
  currency: string;
  date: string;
}

// Reasoning Engine types
export interface ReasoningResult {
  derivedAtoms: Atom[];
  confidence: number;
  steps: {
    ruleId: string;
    inputAtoms: string[];
    outputAtoms: string[];
  }[];
}

// Events and Actions
export interface AtomSpaceEvent {
  id: string;
  type: 'atom-added' | 'atom-removed' | 'atom-updated' | 'pattern-match' | 'rule-fired';
  timestamp: number;
  data: any;
}

export interface AtomSpaceAction {
  id: string;
  type: 'add-atom' | 'remove-atom' | 'update-atom' | 'match-pattern' | 'apply-rule';
  data: any;
}

// Extended types for advanced reasoning
export interface PatternVariable {
  name: string;
  type?: string;
  constraints?: {
    mustBeType?: string[];
    mustBeNodeType?: string[];
    mustBeRelationshipType?: string[];
  };
}

export interface ComplexPattern extends Pattern {
  variables: PatternVariable[];
  relationships: {
    source: string; // Variable name
    target: string; // Variable name
    type?: string;
  }[];
}

export interface RuleSet {
  id: string;
  name: string;
  description?: string;
  rules: string[]; // Rule IDs
  priority: number; // 0-10, higher means apply first
}

export interface ReasoningStrategy {
  id: string;
  name: string;
  description?: string;
  ruleSets: string[]; // RuleSet IDs
  forwardChainingIterations: number;
  confidenceThreshold: number; // Minimum confidence to keep derived atoms
}

export interface ReasoningSession {
  id: string;
  startTime: number;
  endTime?: number;
  strategyId: string;
  results: ReasoningResult[];
  statistics: {
    rulesApplied: number;
    atomsBeforeReasoning: number;
    atomsAfterReasoning: number;
    totalDerivations: number;
    avgConfidence: number;
    executionTimeMs: number;
  };
}