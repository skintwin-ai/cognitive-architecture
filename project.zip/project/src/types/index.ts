export interface Node {
  id: string;
  type: 'supplier' | 'manufacturer' | 'distributor' | 'retailer' | 'customer';
  name: string;
  location: string;
  capacity: number;
  reliability: number; // 0-100 percentage
  coordinates?: { x: number; y: number }; // Used for visualization placement
}

export interface Link {
  id: string;
  source: string; // Node ID
  target: string; // Node ID
  material: string;
  quantity: number;
  leadTime: number; // In days
  cost: number;
  risk: number; // 0-100 percentage
  active: boolean;
}

export interface RiskEvent {
  id: string;
  name: string;
  affectedNodeIds: string[];
  affectedLinkIds: string[];
  severity: number; // 0-100 percentage
  probability: number; // 0-100 percentage
  description: string;
}

export interface Supply {
  id: string;
  material: string;
  quantity: number;
}

export interface NetworkState {
  healthScore: number; // 0-100 percentage
  resilience: number; // 0-100 percentage
  efficiency: number; // 0-100 percentage
  totalCost: number;
  riskScore: number; // 0-100 percentage
}

export interface SimulationSettings {
  riskProbability: number; // 0-100 percentage
  demandVolatility: number; // 0-100 percentage
  optimizeFor: 'cost' | 'resilience' | 'speed' | 'balanced';
  visualizationMode: 'geographic' | 'force-directed' | 'sankey';
  animationSpeed: number; // 0-100 percentage
  showLabels: boolean;
  highContrastMode: boolean;
}

export interface SupplyChainNetwork {
  nodes: Node[];
  links: Link[];
  risks: RiskEvent[];
  state: NetworkState;
  settings: SimulationSettings;
}